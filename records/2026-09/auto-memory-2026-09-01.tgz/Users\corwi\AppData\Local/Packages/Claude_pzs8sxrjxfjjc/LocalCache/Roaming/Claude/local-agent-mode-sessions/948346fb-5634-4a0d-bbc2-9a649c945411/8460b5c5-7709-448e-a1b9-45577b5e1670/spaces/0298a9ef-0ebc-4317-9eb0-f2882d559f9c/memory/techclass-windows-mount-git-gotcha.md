---
name: techclass-windows-mount-git-gotcha
description: git clone fails on the Windows-mounted project folder; clone in the Linux sandbox and tar the files over instead
metadata: 
  node_type: memory
  type: reference
  originSessionId: c59c1997-68af-40ed-84b6-358213c64d8f
---

`git clone` into the Windows-mounted project folder (F:\...\TechClass Reviewer)
fails: "bad config line 1 in .git/config" and leaves `.git/config.lock` +
`.git/branches` that a Windows process holds open and the sandbox cannot `rm`
("Operation not permitted"). `cp -r` onto the mount also mangles (nests dirs,
copies only `.git`).

Working approach: `git clone` into the Linux sandbox (e.g. /tmp), review there,
then move source files (excluding `.git`) onto the mount with a tar pipe:
`( cd SRC && tar cf - --exclude=.git . ) | ( cd DST && tar xf - )`. The Write
tool also writes fine. Verify with `wc -c` against the source. Related to the
`sandboxer` skill. See [[techclass-reviewer-project]].
