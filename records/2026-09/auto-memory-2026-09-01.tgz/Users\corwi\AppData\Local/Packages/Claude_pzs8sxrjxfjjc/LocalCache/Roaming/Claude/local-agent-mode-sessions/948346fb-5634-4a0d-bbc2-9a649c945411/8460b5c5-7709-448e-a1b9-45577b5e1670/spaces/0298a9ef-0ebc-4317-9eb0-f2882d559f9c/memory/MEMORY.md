# Memory Index

- [TechClass Reviewer project](techclass-reviewer-project.md) — review 4 TechnologyClassroom SRE tools, ship upstream PRs; findings in project README
- [Windows mount git gotcha](techclass-windows-mount-git-gotcha.md) — clone in sandbox, tar files to the mount; git clone fails on the mount
- [TechClass email-patch workflow](techclass-email-patch-workflow.md) — submit fixes by email (sysadmin@fsf.org), not GitHub PRs; drafts in submission/
