---
name: techclass-email-patch-workflow
description: "Submit TechClass fixes via the LibrePlanet email-patch workflow, not GitHub PRs"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d04c8875-edfc-4309-b283-69e97c065db6
---

For the TechClass Reviewer project, the user submits fixes via the LibrePlanet
email-patch workflow (https://libreplanet.org/wiki/Contributing_Email_Patches),
NOT GitHub pull requests. "This is perfect for me. I can use the email patch
workflow I wrote here."

**Why:** user authored that workflow; FSF/Savannah is pre-forge. Technical
changes route to sysadmin@fsf.org, content changes to campaigns@fsf.org. All
four TechClass tools are technical -> sysadmin@fsf.org (maintainer Michael
McMahon). Maintainer applies with `git am -3 -k <patch>`.

**How to apply:** ship `git format-patch` output + a paste-ready email body per
repo (one email per repo, group review); don't open GitHub PRs. Deliverables
live in `submission/` under the project. See [[techclass-reviewer-project]].

Proven end-to-end 2026-06-27: all four submissions were applied by the
maintainer and merged upstream (our `[PATCH]` commits, author mplscorwin@gmail.com,
are in each repo's `main`). To confirm a submission landed, clone the upstream
repo and `git log --author=mplscorwin` -- the patches will NOT `git am` again
once merged ("sha1 information is lacking" / "patch does not apply" just means
already-applied, not broken).
