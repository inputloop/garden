---
name: techclass-reviewer-project
description: "Scope and goal of the TechClass Reviewer project (review 4 TechnologyClassroom SRE tools, ship upstream PRs)"
metadata: 
  node_type: memory
  type: project
  originSessionId: c59c1997-68af-40ed-84b6-358213c64d8f
---

TechClass Reviewer = Savannah Hackers / FSF SYSOPS effort to review and upstream
PRs for four TechnologyClassroom (Michael McMahon) SRE tools that protect the FSF
network: WebServerWatcher (Python, restart-on-no-200), LogReview (bash log
summarizer), firewallblockgen (bash, generates ipset/iptables/ufw/shorewall block
scripts), logreview-rs (Rust rewrite of LogReview, early WIP).

All run in production / as root, so correctness and safe-bash bugs are top
priority. Maintainer (Michael McMahon) reviews changes as a GROUP, so bundle
fixes per repo into one branch/PR rather than many small PRs. As of 2026-06-26
every P1/P2 fix is implemented on a per-repo `fix/*` branch with git-am-ready
patches under `<repo>/patches/` and a `<repo>/PR.md` rationale. Submission is by
the LibrePlanet email-patch workflow, NOT GitHub PRs (see
[[techclass-email-patch-workflow]]); paste-ready drafts + attachments are in
`submission/`. As of 2026-06-27 all four submissions are MERGED upstream (P1/P2
work done); only the enhancement TODO remains. Review findings + TODO live
in the project `README.md`
(Summary / TODO / Parking Lot / DONE / History sections, terse GNU-style).
Confirmed P1 bugs: LogReview sed BRE method-strip + substring IP match;
logreview-rs `or_insert(c)` count offset + ignored `column_index`; WebServerWatcher
false-200 regex + silent timestamp-parse fallback; firewallblockgen safe-bash off
+ no input validation. See [[techclass-windows-mount-git-gotcha]].
