---
name: proj-foaf
type: project
---
# FoaF — Bryant's p2p shop + the signing door
FoaF (F:\claude\Bryant\FoaF): Bryant's single-file p2p apps (MeshFeed/Bastion). Now
also home to the **phase0 signing door**: `csh/` (CSH Challenge-Signature Handshake,
Ed25519/libsodium, mutual auth, one authorized_keys line per identity) and **ccspt**
(stdlib skill provenance — "closest thing to a product"). New skills brewing:
**takushi** (courier/last-mile delivery+visibility), csh, ccspt. `meshpoll-critique/`
is a worked reward/critique→blend contrast exercise. Secret file `csh/*.secret` —
never open. [[c4-ambitions]] [[coauthors]]
