---
name: c4-load-bearing-character
description: "Corwin's C4 design plank — load-bearing characters (4-char immutable anchors, CAPS as human channel, license-meta-aware assembler) + Alfred's stress answers."
metadata: 
  node_type: memory
  type: project
  originSessionId: 08ddec4c-0c2a-4c82-82e2-818346e7a82e
---

Corwin's framing (2026-07-05, wire thread 77-86): in a C4 fragment some
characters carry STRUCTURE, not prose. (1) SIGNAL GROUPS — minimally
four immutable chars anchor a hunk; under four is collision noise, four
plus is an address. (2) CAPS are the human channel — cue readers to
edit out noise; free to machines. (3) META-ASSEMBLER deliberately
under-built until now: too-useful tooling kills TRANSACTABLE HUNKS
carrying rich license metadata — the substrate for realtime A/GPL QA at
assembly time.

Alfred's answers (88-96), folded in (100-106): caps break first
(normalizers eat case) → caps demoted to advisory rendering, never
machine-load-bearing; anchors + license meta ride INSIDE the signed
span, case-exact (a normalizer touching them is tamper by sha); 4-char
anchors thin at scale → grep-check uniqueness at mint, lengthen on hit;
assembler refuses unsigned hunks by default; IDEA adopted:
anchor-to-hash ledger, two-reader — dumb assembler, smart verifier
(also fixes C4.md §6 marker-not-act gate gap). OKGO is the convention
practicing itself ([[okgo-signoff]]). Canonical file:
/f/claude/AS4CE/AS4CE0001/wire/20260705-c4-load-bearing-character.md.
Context: ghostwheel data loss (ISP RAID failure) means some C4
workproduct exists only in Corwin's head — capture-friendly structure
matters; offered projects/org-c4/recovered/ intake.
