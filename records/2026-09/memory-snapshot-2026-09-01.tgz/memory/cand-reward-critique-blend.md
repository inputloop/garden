---
name: cand-reward-critique-blend
type: project
---
# Reward/critique→blend contrast loop :SKILL:
From FoaF meshpoll-critique: a model is a stance, a delta is a scored signal (reward
= reinforce / critique = penalize), a blend regroups into the next model — and
running it from **two opposed starting biases** and comparing converts "is my
conclusion stable?" into an auditable check. Caught a real correctness bug a single
pass would have shipped. Skill-shaped; relates to torture's go-harder passes.
#reward-critique-blend
