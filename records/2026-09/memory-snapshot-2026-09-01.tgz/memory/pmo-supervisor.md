---
name: pmo-supervisor
description: The PMO project supervisor at F:\claude\projects\pmo — cross-project status + TODO tooling.
metadata: 
  node_type: memory
  type: project
  originSessionId: 6035d4a1-4d56-4cd9-9b18-94280bf0a6a9
---

PMO ("project-management office") is Corwin's personal project supervisor, living at
`F:\claude\projects\pmo`. It tracks status and TODOs across all his projects.

Design: two tab-separated ledgers are the source of truth — `projects.tsv`
(`key  name  status  publish  summary`) and `todos.tsv`
(`id  project  state  priority  tags  text`). A set of discrete POSIX-`sh`,
stdlib-only programs in `bin/` manipulate them: `pmo-list`, `pmo-add`,
`pmo-done`, `pmo-prio`, `pmo-risks`, `pmo-report` (regenerates `README.md` +
`index.html`), sharing `pmo-lib.sh`. Tags drive sections: `risk` → Risks,
`top`/priority-A → Top Items.

Current form is a static HTML dashboard + generated README. Planned evolution:
migrate the ledger to org-mode TODO files, then serve it live via [[polygram-project]]'s
sibling org-c4 (browser TODO toggling). Publish target is [[publish-code-bru-st]].
Tools rewrite ledgers via same-dir temp + `mv` only — safe on the mount; see
[[git-fails-on-windows-mount]]. Drive it from Cowork via the **`pmo` skill**
(set `PMO_DIR` to the bash mount path, call `bin/` scripts by full path); never
hand-edit the generated README.md/index.html.

Cowork-project integration convention (established 2026-06-27 with AS4CE0001):
a Cowork repo links to PMO via a small in-repo `PROJECT.md` recording its PMO
key, the ledger path, and the publish/remote URL — status stays in the ledger,
not the repo. Confirmed remote for the polygram repo is
`ssh://forgejo@code.bru.st/corwin/as4ce` (PMO publish col reconciled from the
assumed `…/corwin/polygram`); partially resolves the "URLs assumed" caveat in
[[publish-code-bru-st]].
