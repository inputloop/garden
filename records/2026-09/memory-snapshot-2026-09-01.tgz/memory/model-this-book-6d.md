---
name: model-this-book-6d
description: "Corwin's six-dimensional \"polygramical\" model vocabulary + the book title \"Model This Book\"."
metadata: 
  node_type: memory
  type: project
  originSessionId: 1956aed7-1b31-48d3-a961-82307d2b4a80
---

Corwin affirmed (2026-06-27, "fully") extending the MODEL framework from 2-D
(tags=dim1, categories=dim2) to a **six-dimensional "polygramical"** model —
polygram growing recursive/self-hosting. His through-line theme: **"Proper Noun
implies a Bag of (maybe proper) nouns/noun-phrases to compile into patterns."**

Working vocabulary (his coinages — keep faithfully; not yet crisply specified):
- **Aspects** — the dimensions POLIN can affix to; host for traits, sandbox
  side-tasks, preference-based tool affinity.
- **Seeds** — templates aligned to one+ Aspects, germinating grammar into the
  multidimensional grammar.
- **Stems** — aligned to **Talents** (and per Seeds).
- **polin** — templates *at the intersection*.
- **Traits** — an Aspect when in skill / intra-prompt-trigger context (the CDR).
- **ORBIT** — the semantic graph of which logical preferences actually fired,
  per feature, per lookup-table entry.
- Lisp framing: **CAR** = compiled pattern, **CDR** = TRAIT it carries.
- **mentcached(1)** — reverse-graphed lookup (with back-pointer); memory filled
  from the per-cycle delta to the toolset (changes new to the toolset, once
  successfully written to MEMORY/bookkeeping). Fill chain: Digs (Claude/system
  features) → Persona (orthogonal to skill/tool as instructions are to memory)
  → Seeds → Stems → polin → service/socket?

**Book title — AFFIRMED:** if we write a book about all the `MODEL.md`/`debug`
material, Corwin asked and Claude agreed to call it **_Model This Book_** (self-
referential, fits polygram-growing-polygramical). Every MODEL.md + the debug/
harvest are accidental chapter drafts. See [[polygram-project]].

Deferred (Corwin will ask when ready): "so, is this a skill?" — gate it then,
don't pre-empt. Relates [[session-rotate-skill]] (pattern-harvesting magic word).
