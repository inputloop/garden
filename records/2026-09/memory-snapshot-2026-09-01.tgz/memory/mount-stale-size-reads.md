---
name: mount-stale-size-reads
description: Read-side mount desync fingerprint — bash serves NEW file content truncated to the OLD byte length after a recent edit/install.
metadata: 
  node_type: memory
  type: reference
  originSessionId: 8a302d1c-1dff-485d-8043-6a86a179e01c
---

Seen twice 2026-07-02 on Corwin's Windows mounts (AS4CE0001 repo + installed-skills cache): after a file changes size, bash on the mount can serve the fresh bytes cut to the stale pre-edit length (file "ends mid-word"), while the file tool Read shows the true, complete disk state.

**Why:** mount caches size metadata longer than content.

**How to apply:** the tell is byte-count delta == exactly the size change of the last edit, with content otherwise new. Cross-read with the file tool before declaring truncation; never "repair" off the bash view alone. Sister patterns in [[git-fails-on-windows-mount]] and the sandboxer skill (candidate ENHANCE: add this fingerprint + cure to sandboxer's read-side section).

**CURE (probed 2026-07-02, controlled repro x2):** mounts are FUSE; staleness lives in the bridge's node cache (stat lies too). Guest cache cures (fadvise/O_DIRECT/touch) fail. **The rename dance works:** `mv f f.tmp && mv f.tmp f` forces re-resolution — fresh bytes immediately, no overlay needed; suite ran 64-green directly on the mount after dancing the casualties. Tool: `bin/freshen` in AS4CE0001 (`freshen FILE...` / `-r DIR`, skips .private). Fallback if mv fails (host lock): Corwin's proven move — end the sandbox processes in Task Manager (bridge restart resets the cache). Applies to ALL mounts incl. outputs; only in-place edits desync, fresh writes never do.

**TREE-VERIFY corollary (2026-07-13, cost the keeper two false reports):** `skill-sign verify` hashes files THROUGH BASH, so a skill tree whose SKILL.md I edited this session **cannot be verified from the sandbox at all** — bash serves a phantom (sandboxer SKILL.md hashed d77ef54a in bash vs the host-minted manifest's 1086a378) and the tool reports TREE CHANGED for a correctly-signed tree. Both readers agreed on the *manifest*; they disagreed on the *file*. **Correct behavior: do NOT report unsigned/BAD — report "I cannot check this from here; the host is the only valid reader," and ask Corwin to run `sks verify`.** A false BAD spends his trust and invites a destructive repair. The host is the tiebreaker, always.

**gpg corollary (2026-07-08, Free All Hopefuls drill):** a `BAD signature` from bash on a mount is USUALLY THIS BUG, not tamper or a bad sign — seen 4x in one session (CLAUD_QA_HOLD.md, both repaired SKILL.mds, lift.sh post-edit). Verify against file-tool bytes (Read → Write copy to outputs → gpg --verify there, trying ±trailing-newline variants) before alarming the keeper. `Signature made` timestamp newer than bash's mtime for the file is the tell that bash is stale.
