---
name: cowork-cannot-push
description: "Automated git push from the Cowork sandbox to code.bru.st is blocked (SSH host-key verification); commits are manual on Corwin's machine."
metadata: 
  node_type: memory
  type: reference
  originSessionId: bea00e83-ed3a-4ba0-9b3a-c79697653a92
---

Experiment 2026-06-27 (noted for the forge/farm cycle): from the Cowork session
sandbox, `git ls-remote ssh://forgejo@code.bru.st/corwin/as4ce` fails with
"Host key verification failed. Could not read from remote repository." The repo
is *readable* on the mount (`git log` works) but the remote is unreachable —
no SSH known_hosts entry and no key/agent in the sandbox.

**Why:** the sandbox has no SSH trust/key for code.bru.st; this fails *before*
the [[git-fails-on-windows-mount]] write hazard even applies.

**How to apply:** treat commit+push as a manual step Corwin runs in his own
shell. Claude should provide ready-to-paste commit commands at each commit point
and ask the user to confirm ("Done yet?"), not attempt the push itself. Enabling
automated publish would require provisioning an SSH key + known_hosts inside the
runtime — a separate, explicit decision. Publish target is [[publish-code-bru-st]].
