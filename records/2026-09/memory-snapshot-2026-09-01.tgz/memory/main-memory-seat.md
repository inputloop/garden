---
name: main-memory-seat
description: AS4CE0001 (Vibrobeast) is the seat of local memory — MAIN MEMORY; SAVANNAH keeps specific cases.
metadata: 
  node_type: memory
  type: project
  originSessionId: b04f62c9-bb55-4510-ade7-ece28827edfe
  modified: 2026-09-01T09:12:46.672Z
---

Decision (Corwin, 2026-09-01): **this project (AS4CE0001 / Vibrobeast) is the seat of local memory — MAIN MEMORY** — completing the "notes hub" declared in model.md on 2026-06-29.

**Semaphore `SEAT`**: bare `SEAT` = the default seat (`F:\claude\AS4CE\AS4CE0001\memory`); `SEAT@SAVANNAH` = SAVANNAH's routine carve-outs (session-memory / LABTAIL `NOW`, signing authority, canon source-of-truth). Lowered only by Corwin (or C4 when it takes the reins).

**Why:** memory is split across parallel stores — my reflex auto-memory ≠ the store-of-record hub ≠ the SAVANNAH enclave — and was pinned by path not hash, so the data-root migration stranded notes after 2026-08-17. A declared seat + a hash-keyed manifest is the fix.

**How to apply:** land memory-shaped notes in the seat by content-identity; short-term I manage the semaphores, C4/ghostwheel takes the reins later. Model + plan: `AS4CE0001/MENTAT-MAINMEMORY-SEAT-2026-09-01.DRAFT.md`.

See [[memory-stores-map]], [[manifest-hash-not-path]], [[feature-no-math]], [[mentat-defrag-thread]], [[memory-semaphores-v1_1]].
