---
name: polygram-test-kit-gaps
description: Test/robustness gaps in polygram exposed by the externs.json truncation.
metadata: 
  node_type: memory
  type: project
  originSessionId: 3aec2ca0-f922-4743-b470-15f23aa904db
---

The 2026-06-27 externs.json truncation was an external write-desync, not a code bug, so no unit test would have prevented it ([[git-fails-on-windows-mount]]). It exposed gaps that were **implemented in polygram v0.3.0 (2026-06-27, now 25 tests passing)**:

1. DONE — `ManifestError` added; `Manifest.load` guards `json.loads`, non-dict, and bad records with actionable messages; `cli._manifest` catches it. Tests: truncated / non-object / bad-record.
2. DONE — `Manifest.reconcile(externs_dir)` cross-checks manifest vs `externs/<name>/` clones; `doctor` runs it and exits 1 on issues (already flagged `savane-upstream/` as not-a-git-clone). Tests: missing-clone, unregistered-dir, doctor corrupt/clean.
3. DONE — `Manifest.save` now writes to `.tmp`, verifies bytes, `os.replace`, re-reads to confirm. Test: atomic save leaves no tmp + round-trips.

Kit re-verified green 2026-07-04: **76 tests OK** — but only from a /tmp copy with fresh bytes. The mount served stale/truncated gate.py, review.py, cli.py (phantom SyntaxErrors); [[mount-stale-size-reads]] cure applied. Never certify red-looking results straight off the mount.
