---
name: reject-then-promote-lesson
description: Promotion-path defect found 2026-07-04 — wanting to read before signing was only expressible as REJECT; signing is the dignity moment; dist already in-signs.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: fe8c977f-1410-426c-a8e4-fc342ef2ae36
---

Early in QA-desk practice Corwin hit "reject-then-promote": the only way to buy
time to *read what he was about to sign* was to file a REJECT, which the system
read as "wanting to think is a problem." His instinct ("have I read this thing
I'm going to sign?") was correct; the defect is the missing state.

**Why:** Corwin locates the ceremony's dignity in the signing itself. A pause to
read must be a first-class REVIEW state, distinct from REJECT — no rejection
record for diligence. Also: `dist` / `bin/release --apply` already in-sign; he
hadn't known, and wrote hand-rolled wrappers to compensate.

**How to apply:** Promotion tooling ([[polygram-project]], skilltank promote
helper) gets REVIEW ≠ REJECT. Retired `sign-polygram-dist.sh` (MANIFST typo →
manifests silently never signed; hardcoded sign.sh path). Evidence of the era:
0.5.4 artifacts in dist/ have no .asc; 0.6.0 fully signed via `bin/release
--apply`. One blessed signing path; wrappers are how manifests ship unsigned.
See [[qa-hold-desk-live]], [[session-rotate-skill]].
