# Reuse shell helpers
Keep shell helpers reusable across skills. #shell-tooling
