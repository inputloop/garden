---
name: session-usage-sweep
description: "JSON dataset + model doc at AS4CE0001 tallying tool-call activity across 86/287 local Cowork sessions; extendable, portable method."
metadata: 
  node_type: memory
  type: project
  originSessionId: c8ff7f97-a18b-4f30-aa16-0f62c7a2bb9d
  modified: 2026-09-01T16:27:53.949Z
---

Landed 2026-09-01 at AS4CE0001: `session-usage-sweep-2026-09-01.json` (86 rows,
rank/session_id/title/file_ops/web_ops/other_ops/flags, totals file=1292
web=39 other=465 grand=1796) plus `SESSION-USAGE-SWEEP-2026-09-01-MODEL.md`
(methodology, categorization table, known limitations, how to extend cold, how
to repeat in another project).

**Why:** Corwin asked to have this session's chart-building sweep (tool-call
counts by category, via `mcp__session_info__list_sessions` /
`read_transcript`, as a proxy for real token telemetry which isn't exposed
cross-session) landed as data plus an assistive static model, rather than
left only as a chat chart — so it can be updated here or repeated in another
workspace without re-deriving the method.

**How to apply:** Before re-running any future usage sweep, read the MODEL.md
first — it names the exact tool calls, the categorization table, and the
extend-cold procedure (diff session_id lists, append from rank 87, re-sum
totals rather than adding deltas by hand — a mistake this round's own prose
made once, corrected in the model doc). The model doc also documents a live
correction: an earlier prose reply this session stated "~2079" total tool
calls; the programmatically verified figure is 1796. Trust the JSON's
`totals` block over any prose number.
