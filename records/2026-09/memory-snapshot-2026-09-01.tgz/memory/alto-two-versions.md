---
name: alto-two-versions
description: "altorewired — worn copy is Corwin's hand-typed v0 (2026-08); Sonnet-authored rewrite exists but is UNWORN and unlocated from Cowork; alto = the producer-side-triggers organ, hand-grown"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5bdd7ed0-d0a8-4f49-8d8f-86a4f7fd1d2b
  modified: 2026-08-17T08:03:24.220Z
---

The installed altorewired skill is Corwin's hand-typed seed ("Alto Re-wireD" — plan to
replace wire; bastion composing local tooling; return-tail file under /g/wheel/ that
Claude cannot read by design; "Trigger on most prompts"; body says when worn, mention
first the takeaways it needs). The Sonnet-authored rewrite arrived as
AS4CE0001/Inbox/altorewired-draft.skill (2026-08-17): REVIEWED, DO NOT WEAR — capture
by canon gravity (9 skills cited, each amputating an organ; self-lane "to yourself for
later" deleted and labeled load-bearing). Keeper confirmed the diagnosis, removed the
wire connector, plan = grow alto back in the Vibrobeast chamber. Review + regrow plan +
Step-0 relay card at AS4CE0001/ALTO-REGROW-2026-08-17.md; salvage: NOT-ATTEMPTED
wording, fire-broadly/write-rarely split. Bare-room rule for alto design sessions: wear
alto alone; canon by fetch, not by description.

Key kinship: alto is the same organ as memory/producer-side-triggers.md (AS4CE0001,
2026-08-17 removal pass) — a thing that fires on lifecycle/output-side events, not on
user words. Any wear decision should run the new kit: removal test (name the artifact
that breaks), door-test discriminator, fires-vs-remembered, candor-gate opt-in vs
always-on. Wear ONE version only (same name = replace). /g/wheel return-tail cannot be
verified from the sandbox — verifying is reading; needs a keeper-side check or card.
Related: [[c42-transition-recommend]], [[persona-usage-model]].
