---
name: session-rotate-skill
description: New curated skill session-rotate — rotates per-project session files at hand-off; built via the polygram pipeline.
metadata: 
  node_type: memory
  type: project
  originSessionId: 1956aed7-1b31-48d3-a961-82307d2b4a80
---

**session-rotate** is a curated polygram skill (in `skills/session-rotate/`)
that rotates a project's per-session files at hand-off: snapshots `.model.md`
into `.models/` with a `Version:` bump, moves `.last-prompt.md`→`.prompts/` and
`last-response.md`→`.responses/`, and scaffolds the next prompt. Tool:
`scripts/rotate.py` (stdlib, **dry-run by default**, `--apply/--bump/--scaffold`,
collision-safe). Built 2026-06-27 via skilltank→polygram `review --promote`→
hand-author→QC AND-gate (skillbuilder+SRE PASS)→`dist --format skill`
(`dist/session-rotate.skill`). Not yet installed — Corwin installs via desktop
"Save skill". Distinct from [[pmo-supervisor]] (cross-project ledger) and
sandboxer (mount desync). See [[polygram-project]].
