---
name: prefers-concise
description: "Corwin wants concise, direct answers with minimal verbosity."
metadata: 
  node_type: memory
  type: user
  originSessionId: ef0e765b-aaa0-4746-93c2-25c8f0f19ff5
---

Corwin prefers responses as concise and direct as possible — cut words that don't change the point. Minimal explanation, no filler.
