---
name: memory-stores-map
description: "The parallel memory stores — A auto-memory (fenced), B AS4CE0001 hub (SEAT), C SAVANNAH enclave, D DEFRAG old-home."
metadata: 
  node_type: memory
  type: reference
  originSessionId: b04f62c9-bb55-4510-ade7-ece28827edfe
  modified: 2026-09-01T09:12:54.923Z
---

The MAIN MEMORY fragmentation, mapped:

- **A — Cowork auto-memory**: `…\spaces\c7c21b10-…\memory\` (MEMORY.md + ~46 notes). My *reflex* write-target this surface. Under the AppData app-data root → **fenced / migration-fragile** (the app retires its active root on a move). Disposition: `bring-in` → the seat.
- **B — AS4CE0001 hub**: `F:\claude\AS4CE\AS4CE0001\memory\` (MEMORY.md + ~35 notes) + in-tree `models/ book/ journal/`. Declared store of record (2026-06-29); git; signed shelf. This is the **SEAT**.
- **C — SAVANNAH enclave**: withdrawn (not under `F:\claude` right now). Holds LABTAIL `NOW`, session-memory, `.signing-authority/`. `SEAT@SAVANNAH`; re-mount to reconcile.
- **D — DEFRAG old-home**: `F:\ClaudeDesktop*` (retired root — mounts fine). The curated **20** (pinned in `2026-08-31_orphan-manifest.tsv`) + **1081** note-shaped review candidates.

Key fact: the app fences its **active** data root + home folders; a **retired** root mounts fine — so moving the root never fixes reachability; the fix is architectural (durable spine in always-loaded layers + notes in a mountable non-root path).

See [[main-memory-seat]], [[git-fails-on-windows-mount]], [[sandbox-ephemeral-per-session]].
