---
name: manifest-hash-not-path
description: "Reseat rule — a path is an address, a hash is an identity; key memory manifests on content, not location."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b04f62c9-bb55-4510-ade7-ece28827edfe
  modified: 2026-09-01T09:13:00.928Z
---

The C4 rule (frag `a-manifest-that-pins-a-path-is-a-hook`): a manifest that pins `./foo` *knows where* the file is — it does **not own** it. So key on **content sha256 (identity)** and carry the path as a **hint**.

**Why:** path-pinning made the data-root migration (`C:\` → `F:\ClaudeDesktop*` → `/h/CLAUDE`) read like a *violation* instead of a *change-of-address*, which is how notes got stranded. Hash-identity makes motion cost only a hint-refresh; identity never moves.

**How to apply:** `MANIFEST-MEMORY` + `orphan-manifest` key on sha256; verify by hash on two readers (SEAMS); re-home the check *with* the file — never forbid the move. Motion + carry-the-check-forward is the whole obligation.

See [[main-memory-seat]], [[mount-stale-size-reads]], [[mentat-defrag-thread]].
