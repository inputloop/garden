---
name: okgo-signoff
description: "Corwin's -OKGO sign-off convention — approved drafts return as a clearsigned file named with -OKGO; the acronym is his four-state taxonomy."
metadata: 
  node_type: memory
  type: user
  originSessionId: 08ddec4c-0c2a-4c82-82e2-818346e7a82e
---

Corwin approves plans by returning a clearsigned copy of the draft under
a filename carrying **-OKGO** (minted 2026-07-05, first use: the EPMO
convention draft in Vibrobeast-Meets-Claudewin).

The taxonomy: **O** Operational · **K** Known-Variable (unpinned by
intent, scent-heavy) · **G** Ghosts (active signed-or-unsigned life
having Providence in-network) · **O** Operational again — must pass all
asserts O<->O when boxed as such.

**How to apply:** when Corwin says a plan is approved "under an -OKGO
name," freeze the draft (no edits — edit-after-sign breaks signatures),
watch for the -OKGO file, verify its clearsign against his pinned key
ECE77CF417C76C1ACFCE7C2B5B6135511580F007 before acting on it. OKGO is
itself a demonstration of [[c4-load-bearing-character]]: a four-char
immutable caps anchor.
