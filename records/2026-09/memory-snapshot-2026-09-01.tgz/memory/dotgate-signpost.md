---
name: dotgate-signpost
description: ".gate dotfile convention — access sign-post at directory roots, shipped in polygram 2026-07-02"
metadata: 
  node_type: memory
  type: project
  originSessionId: ba152998-a6dd-4945-9b06-3fe7164ecefa
---

`.gate` at any directory root declares consented tool traffic: `policy`
(read-write/read-only/write-only/none), `reason`, `since`, plus optional
`embargo` + `lift`. Nearest sign walking up governs; ungated = silence, not
consent; invalid policy fails closed. Embargo gates egress (`publish` op),
orthogonal to policy — you can read/work an embargoed tree, not move it out.
Corwin-affirmed core: no timer ever lifts an embargo; a date passing is
silence; a human lifts by editing the sign (lift: names who/how), file history
is the audit trail. Implemented in polygram (`polygram/gatefile.py`,
`polygram gatefile PATH [read|write|publish]`, exit 0/1/2); root `.gate`
posted on AS4CE0001; 64 tests green (incl. resolve-once fix per SAVANNAH
cite #2). COUNTERSIGNED by SAVANNAH 2026-07-02; polygram recognized as
foundry project of record on interlock-restating conditions (SAVANNAH canon,
PMO tracker, dist-respects-embargo once bound — PMO #91, QA-3 holds).
OPPORTUNITY: offer convention beyond polygram (PMO #90). Corwin pushed from
host. NB: mount desync also hits the outputs folder after in-place Edits —
only fresh writes sync; overlay-verify anything edited in place. Corwin's design words: "Don't build the cathedral; ship the
sign-post." Follow-ups deliberately deferred: ethicsminions guard over tool
traffic, regression reseed with SAVANNAH after PoC. Practice: request project
mounts as needed but avoid `.`-lead private folders; `policy: none` is the
in-band private marker. Relates [[git-fails-on-windows-mount]],
[[mount-stale-size-reads]] (hit again verifying this: stale cli.py bash-side,
verified via /tmp overlay).
