# producer-side triggers — the "skill I should have fired" hole (2026-08-17) :SKILL:

Named mutant, on record twice in one day: C4 held magic-words-persona while
grading a shelf against it; Vibrobeast held run-card while typing card-shaped
prose in chat (keeper caught it: "those run-cards do not quite look like a
skill made them"). Pattern: **skills fire on the USER'S words; nothing fires
on the shape of MY OUTPUT.** The trigger surface faces inward only.

The check (keeper-invited, baked into model.md v13 REMOVAL DISCIPLINE):
before any hand-back, name the shape of what is being handed back and check
the rack for a skill that claims that shape — **fire it, or say the miss in
one line. Never silent.** Ladder, not gate.

Delivery tier: persona (always-loaded line), because hand-backs utter no
magic words — only the loaded tier fires there. Mint a mechanical gauge
(descriptions grepped for artifact-nouns → checklist) ONLY if say-it lines
show recurring misses: one mutant seeds, recurrence mints (tool-lifecycle).
skilltank verdict when it reaches the desk: likely ENHANCE (session-rotate
close sweep + this line), not NEW.

Net-ceremony accounting, honest: +1 loaded line, no human step, no gate;
mutant-backed and keeper-invited. Legitimate growth is falsifiable growth.
