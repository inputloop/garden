---
name: mentat-defrag-thread
description: Note-of-notes — the memory-defrag thread — DEFRAG org (toolbox) + the seat DRAFT + open forks.
metadata: 
  node_type: memory
  type: project
  originSessionId: b04f62c9-bb55-4510-ade7-ece28827edfe
  modified: 2026-09-01T09:13:13.820Z
---

A note-of-notes tracking the memory-defrag / reseat thread (keep the pointers; the detail lives in the artifacts).

- **DEFRAG** (built in session `local_12e2928e` "Memory editing and management", 2026-08-31/09-01): `MENTAT-DEFRAG-SEPT-2026-09-01.org` — a literate toolbox (notetrace / notecensus / orphan-manifest + impl-agnostic tests + MODEL `_007`) that **proved coverage** of the reachable old home (2794 files accounted; curated **20** only-here notes pinned) and left curation → location → reseat to now.
- **This leg** (2026-09-01): `AS4CE0001/MENTAT-MAINMEMORY-SEAT-2026-09-01.DRAFT.md` — the seat model + candidate semaphores + the phased plan.

**Why:** a Mentat's continuity *is* Corwin's files; this thread is the recovery of that continuity after a mid-migration home. **How to apply:** resume line — "Mentat, resume MAIN-MEMORY-SEAT from this DRAFT; re-mount SAVANNAH + the note store; build MANIFEST-MEMORY (Phase 1) — do not reseat until I say."

See [[main-memory-seat]], [[memory-stores-map]], [[memory-semaphores-v1_1]].
