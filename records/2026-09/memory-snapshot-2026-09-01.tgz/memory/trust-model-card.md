---
name: trust-model-card
description: "The card's trust arc — a write is untrusted by default; receipts prove integrity, not trust; trust returns via a known baseline."
metadata: 
  node_type: memory
  type: reference
  originSessionId: b04f62c9-bb55-4510-ade7-ece28827edfe
  modified: 2026-09-01T11:49:43.749Z
---

The C1–C4 card is about **trust**, not just a pipeline (Corwin, 2026-09-01):
1. **Untrusted at discovery** — a write seen *as from* my own tool.
2. **Still untrusted** moving among FS actors, **even with receipts**.
3. Appends outward from the `<|` moment, out the **tool layer of record** (Tool Library).
4. **Trust regained** — by receipting a tool we already trust (classic: gpg/ASCII-armor) **and** the thing **returning toward a specific known record**, joined to used-tested-uncomplained baseline tooling, archivist-tended.

Key point: **receipts prove integrity + provenance, not that the actor is to be believed** — trust returns via a **known baseline**, not the receipt alone. "Two sources, both Corwin" = a known record + trusted tooling agreeing (a rudimentary dual-source when both are him). His LENS question (is "still untrusted with receipts" wrong/uncommon?) — my read: not wrong, not uncommon; it's the honest default. **Banked as LENS fodder** (ritual pass held per his sequencing).

**The loop (2026-09-01, 2nd pass):** the trust arc is **circular** — `H:MEMORY(GRAPH)=|C4|>|<|*=HURISTIC=|_/` wraps back to its dated origin. The danger it exposes: a trusted person↔C4↔iT relationship can **implicitly broker unknown inputs** from third parties (humans) arriving via the **Wire**. Guard: Wire-arrived input **never inherits** the Corwin↔iT trust. `|_/` = the **floor** (on-ramp admission — no input accepted that didn't come via our own on-ramps), and **chadtab** (`chadtab.4`, Perl-homage grammar) is where those on-ramps are declared — so the floor + chadtab already ARE the gate. (minions-NOTICE; captured in C4-SPOILERS. Note: "MANIFEST" in an earlier pass was my OCR, not the keeper's word.)

See [[manifest-hash-not-path]], [[c4-spoilers-capsule]], [[vibrobeast-model]].
