---
name: enable-journal-book
type: project
---
# Remember to enable journal + book for the chamber
Carve-out from full-research mode: journal/ and book/ memory are the habits we are
remembering to TURN ON for this chamber (as modelthisbook has), not to skip. Not yet
present here — enable deliberately, don't let it lapse by inattention.
