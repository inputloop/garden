---
name: corwin-hosting-teaching
type: user
---
# Hosting provider who teaches as a rule
Corwin runs free-software hosting and has, over many years, **donated use of and
service on systems** he maintains. As a rule he spends real time **teaching people
how to do things** so they can make use of what he offers — teaching-as-service is
part of the offering, not a side effect. (Ghostwheel / ex-Fosshost lineage.) [[corwin-public-fsf]]
