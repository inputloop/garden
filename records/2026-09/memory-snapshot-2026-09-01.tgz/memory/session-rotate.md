---
name: session-rotate
type: feedback
---
# Rotate session files on hand-off :SKILL:
Across projects (skzb `pm`, polygram itself) every session ends with the same
ritual: copy the live `.model.md` to `.models/model-<date>.md` and bump its
Version header, rotate `.last-prompt.md` into `.prompts/`, write
`last-response.md` and rotate prior into `.responses/`, then scaffold the next
session's prompt. Repeated by hand every session; a runnable rotation would do
it the same way every time. #session-rotate #handoff #posix #shell-tooling
