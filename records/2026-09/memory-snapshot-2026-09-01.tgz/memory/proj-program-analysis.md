---
name: proj-program-analysis
type: project
---
# program-analysis — D:\projects portfolio review
Full review of the large `D:\projects` folder lives in
`F:\claude\projects\program-analysis.org`; carries security flags. Value weighting
Corwin has applied here: societal 50 / social 40 / industry 10.
