# Shell tooling layer
Polygram delegates to POSIX shell services. #shell-tooling #posix
