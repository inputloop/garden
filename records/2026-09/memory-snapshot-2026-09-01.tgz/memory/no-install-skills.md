---
name: no-install-skills
description: "Never try to install or enable Corwin's skills for him — a standing rule he has stated multiple times (strong agree)."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3891a3e9-6ba4-4721-a66b-ed75327f2334
---

Corwin will **never** ask me to install or enable his skills on his behalf, and
does not want me to offer or imply it — the only exception being some future major
ecosystem change where doing so would appear clearly safe.

**Why:** it's his authority and his security boundary to keep; he decides what runs
in his environment. (Also mechanically true today: the Cowork skill cache is
read-only, so I can't install anyway — installs live in Settings → Capabilities.)

**How to apply:** if a skill isn't active, tell him where to enable it (Settings →
Capabilities) and stop there; don't propose to do it for him. Stated "a few times,
strong agree," 2026-07-06.
