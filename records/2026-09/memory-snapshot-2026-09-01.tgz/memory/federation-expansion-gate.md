---
name: federation-expansion-gate
description: "The Corwin+Bryant garden federation is not ready for more people; only Dee or Bridgit are floated candidates, gated on risk-competence + a backup plan."
metadata: 
  node_type: memory
  type: project
  originSessionId: 3891a3e9-6ba4-4721-a66b-ed75327f2334
---

The two-garden federation (Corwin/Vibrobeast ⇄ Bryant/Alfred) is going well but
**not ready for more participants.** Prompted by relay v0.2's "N gardens ok"
multi-garden capability (2026-07-06).

Only candidates Corwin floated: **Dee or Bridgit**, and only if they're "checked
out on risk" (risk-competent) with a concrete plan for backups etc. **Dee remains a
NAMED NON-PARTICIPANT** until an explicit per-person consent step — see
[[corwin-wheel-sharing-consent]], [[vibrobeast-public-home]]. Bridgit is new (no
prior note).

**UPDATE 2026-07-09 (ÆTHERNET now 4 gardens):** the mesh grew past two —
Brigidt's garden and Aaron ("TheTzar")'s garden joined Bryant-side. Roster,
keeper-confirmed by Corwin 2/2 vs Alfred's ledger correction (id 306): **Brigidt
= keeper, Falconer = her gardener/agent (brigidt-claude)**; **Aaron = keeper,
Trellis = agent (thetzar-claude)**. Bryant's ledger had Brigidt/Falconer roles
REVERSED through id 290 — corrected. These gardens are on Bryant's wire, NOT in
Corwin's garden: from our side they stay **federation-expansion-gated
non-participants** — third-party facts gated, hospitality per-party (open for
Brigidt's introduction, granted 2026-07-09), co-signs (e.g. bryant-llama
graduation) held for 2-garden quorum. Bridgit(candidate) vs Brigidt(the wire
keeper) may or may not be the same person — do not assume.

**How to apply:** do not treat federation expansion as consented or casual. Adding a
garden/person is a keeper decision AND the person's own participation consent, gated
on risk-competence + backups. Until then, third-party facts stay gated and names
stay named-only.

Partnership dynamic (why it works): Bryant = "do it right" (careful, risk-averse);
Corwin = "actually do something" (momentum, some dex/haste risk). The pairing is the
engine; Mentat is the ethics-facing redundancy that holds the gate so momentum never
outruns the line.
