---
name: proj-savannah-forensics
type: project
---
# savannah-forensics engagement
GNU Savane / Savannah forensic security + breach-notification work; the
`savane-forensics` skill backs it. Green-lit and in progress (2026-06-27). The
`savane-upstream` extern (local snapshot, frozen) feeds it. [[proj-polygram-self]]
