# registers — the change-budget lore + the write dilemma (Corwin, 2026-08-17, in-session; UNWRITTEN elsewhere as far as today's sweep saw) :SKILL:

Pre-Claude/pre-ML, registers were his solution to the discipline-vs-motion
problem. His arithmetic, near-verbatim: **"9 can change together, 17 have to
hold it; otherwise 2 can change pretty fast if the nine lay off; then we can
have inverted designs where we work with different arrangements of what is in
the 9 or sets of 2s we group."** (My parse, marked as parse: 17 registers
total = the frame; a coordinated 9-set change requires the whole frame
holding; pairs move fast while the nine are quiet; membership of 9-vs-2s is
itself a design surface — inversions. Uncertain reading; check with him
before it hardens.)

Then the dilemma that, in his words, is **"really how C4 got so out of
control, not about gating ai or anything else"**: certain registers are
ALWAYS-CHECKED (every tool consults them) — but they must also be WRITTEN,
writes can fail or be bogus and want backout, and **"everyone is always
sending new."** Read-stability under write-pressure.

The answer-pattern poly already RUNS (advice/, latest-terminal-wins,
6 tests; the gotchas ledger's "state tables die, event/history tables
remember"; run-card's "supersede, never edit"): an always-checked register
should be a DERIVED VIEW over an append-only, per-writer-authenticated
ledger. Writes = cheap appends that cannot corrupt the read; backout =
superseding row; a bogus write = a row the fold does not recognize
(quarantine by non-recognition, no deletion); concurrency stops being the
threat because the ledger WANTS new. c4prime is already this shape for one
register ("generated fresh, never hand-written — reads the tree at run
time"). Candidate generalization for C4's always-check registers: each gets
an event lane + a named fold; the register file becomes a regenerable cache.

Adjacent lore, same conversation: he spent 2023 "talking myself out of
graduating from thinking about making a framework to def not falling into
making a language" — and c4 now carries assy, meta, c4ql (C4-LANG.md;
three-languages fact). The year of restraint is why the language has
receipts: it waited until the mutants existed.

Wants C4 intake (registers are C4's organ; keeper couriers between gardens).
Feedstock tags: registers, change-budget, event-ledger, fold, c4ql.
