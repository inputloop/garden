---
name: semaphore-model-pairing
description: "Really-good items get a MODEL to go with their semaphore, at minimum — the model is the substance the signal points at."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b04f62c9-bb55-4510-ade7-ece28827edfe
  modified: 2026-09-01T12:23:30.913Z
---

Corwin, 2026-09-01: **a really-good item gets a MODEL (a `models/` shelf `MODEL-*.md`) to accompany its semaphore, at minimum.** A semaphore is the signal; the model is what it points at. A signal with no model points at nothing. More maximally: fold what's been learned into the model so it's integral.

**Why:** the good, load-bearing, reused items earn a write-up; it keeps signals honest. **How to apply:** when an item is really-good, pair its semaphore row with a MODEL on the shelf. First instance: `models/MODEL-memory-grow.md` (pairs `SEAT`/`MANIFEST-MEMORY`/`GROW`).

See [[memory-semaphores-v1_1]], [[persona-doorway]], [[vibrobeast-model]].
