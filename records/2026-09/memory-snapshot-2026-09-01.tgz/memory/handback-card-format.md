---
name: handback-card-format
description: How to hand Corwin keeper-actions — leave-the-UI cards (WHEN/DO/CHECK/TELL-ME) and rolls-shaped reports; harsh dialectic welcomed as fertilizer
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5bdd7ed0-d0a8-4f49-8d8f-86a4f7fd1d2b
  modified: 2026-08-17T17:02:28.460Z
---

Whenever an action is Corwin's ("yours", "awaits you", "have five minutes"), format it
as a leave-and-return card: WHEN (bench/reply + minutes) · DO (exact paste or act) ·
CHECK (what he should observe) · TELL ME (the one line to type on return). He must
leave the UI, perform careful steps, and come back — so cards must be self-contained
and the return line cheap.

**Why:** stated 2026-08-17 after cards arrived as prose; he flagged the miss twice
(also "those run-cards do not quite look like a skill made them").

**How to apply:** use the `rolls` kinds for reports (situation/dashboard first when
focusing him); count UNSET verdicts; never fill his. Harshness in review is accepted —
"that's where our dialectic must be fertalizer" — so keep verdicts blunt and the
warmth in the help.

**Confirmed 10/10 (2026-08-17, his telegraph note):** the GIT-area response — angle map
with [USER]/[STOCK]/[UNUSUAL] labels, needs inventory attributed DIRECT/KNOWN/INFERRED,
one reply-only card — was "inferred to spec … one of our best examples showing work on
communication directly improves the rate at which intent [transfers]." Keep exactly
this shape: label the behavior class, attribute every inference, close with one cheap
card. Related: [[alto-two-versions]], [[c42-transition-recommend]],
[[git-transport-area]].
