---
name: qa-hold-desk-live
description: CLAUD_QA_HOLD is enabled as a live operating mode; skill intake goes through it.
metadata: 
  node_type: memory
  type: project
  originSessionId: aefee152-775c-42fd-9fff-eb7a26426277
---

2026-07-04 Corwin enabled "AI hold": the CLAUD_QA_HOLD desk (AS4CE0001/CLAUD_QA_HOLD.md) is live operating mode — prepared changes park in `claud-qa-hold/`, the box pops (AskUserQuestion: Apply/Hold/Reject), decisions date to `advice/`.

Desk record so far: QA-7 skill-sign APPLIED w/ fixes; QA-8 security-digest HELD by Corwin (staged, not riding 0.5.5); QA-5 guard-provenance APPLIED 2026-07-04 — folded to skills/ethicsminions/references/, rider satisfied by the fold itself (Corwin present/initiating; his words: "I don't want to lock myself out"), rides 0.5.5.

First live apply: QA-7, the skill-sign intake. Haiku's signing-skill delivery (F:\claude\AS4CE\FreshLocalGossip\skill-sign-haiku-2026-07_Jul_03_Fri) arrived unsigned with a wrapper/payload mismatch (top SKILL.md was a different skill, `security-digest`) and two breaking bugs (bundle dropped .signature.asc via dotfile glob; verify didn't pin the key). Adopted with fixes as skills/skill-sign: signature covers a whole-tree sha256 manifest, pinned VALIDSIG verify, zip-slip guard. security-digest still awaits its own intake call. Rides 0.5.5 with the drift-fold trio ([[polygram-project]]).

**Why:** external skills — even from cooperating authors/models — go through the intake gate; the QA-7 catch is the standing proof it earns its keep.

**How to apply:** when something is prepared but not blessed, park + pop the box; never land directly. Intake reviews follow the QA-7 shape: read everything, security-review executables, verdict with numbered findings, box.
