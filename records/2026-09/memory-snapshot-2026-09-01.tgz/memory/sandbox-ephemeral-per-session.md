---
name: sandbox-ephemeral-per-session
description: "The Cowork Linux sandbox resets every session (empty gpg keyring, no installed pkgs, /tmp gone); only mounted files + memory persist. Cold-start needs rehydration."
metadata: 
  node_type: memory
  type: reference
  originSessionId: 3891a3e9-6ba4-4721-a66b-ed75327f2334
---

Each session the sandbox starts **cold**: gpg keyring empty, pip/npm installs gone,
`/tmp` cleared, no running processes; working context holds only the auto-loaded
`MEMORY.md` index until files are re-read.

- **Persists:** mounted folders (`F:\claude\...`), the memory dir, and anything
  stored AS A FILE (keys, `.asc`, catches, foundry).
- **Ephemeral per session:** sandbox keyring, installed packages, `/tmp`, processes,
  in-context memory beyond the index.
- **Never persisted (by design):** the wire bearer code — re-handed each session via
  the question tool.

**Gotcha seen 2026-07-06:** Bryant's pinned key lived as `build/bryant.asc` but
verification failed until `gpg --import` this session — the ring doesn't carry over.

**Opportunity:** a session-start **rehydration step** = keys-from-stash import
(`gpg --import keys/*.asc`) + context load + code re-hand → cold session lands warm.
This is why bubble-chamber "land to disk" matters. [[bubble-chamber-method]]
[[wire-claudewin-alfred]]
