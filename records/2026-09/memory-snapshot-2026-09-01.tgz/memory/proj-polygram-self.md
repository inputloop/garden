---
name: proj-polygram-self
type: project
---
# polygram (this chamber, AS4CE0001)
Gated agent-skill synthesis, v0.5.2; stdlib-only. Now also the **hub for general
and per-project memory** (no notes flow back to the old main stash). Pipeline:
memory tags → candidate → gate (PASS/HOLD/REJECT) → advice → synth → dist (.skill
bundles). [[proj-pmo]] [[proj-modelthisbook]]
