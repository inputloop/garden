---
name: reflection-family-drift
description: "Design direction — enhance eclipse to name the LENS + wider/narrower \"reflection\" techniques; couple to Drift (eventual). CANDIDATE."
metadata: 
  node_type: memory
  type: project
  originSessionId: b04f62c9-bb55-4510-ade7-ece28827edfe
  modified: 2026-09-01T09:22:42.183Z
---

**CANDIDATE design direction (Corwin, 2026-09-01), pending his go — proposal, not executed.**

- **Enhance eclipse/microscope to mention the LENS** and be clear that "reflection" is a *family*: **wider** techniques (the LENS — nearly all contexts) and **narrower** ones (eclipse-pass — debugger-on critique of one target). Eclipse is a narrow reflection; the LENS is the wide one.
- **Couple to Drift — "eventual, so far":** running a wider/narrower reflection pass is legitimate self-directed **drift** spend, logged. Concrete hook found live: the ethicsminions `drift` guard is currently **SKIPPED** (no `--expect` attestations file) — coupling reflection↔drift could feed it.

**Why:** gives the reflection techniques one home + a funding model (drift), and puts the minions' unused drift guard to work. **How to apply:** route the eclipse-pass edit through skilltank → skill-creator on Corwin's go; **do not overwrite his installed skill unilaterally** (govern gently; keeper's tool). Draft insertion prepared in-chat. See [[lens-discipline]], [[sandboxer-eclipse-2026-07-12]].
