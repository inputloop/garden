---
name: free-all-hopefuls-drill
description: The Free All Hopefuls drill (first run 2026-07-08) — sweep every parked/pending item to a keeper decision via boxes; outcomes and the ritual shape.
metadata: 
  node_type: memory
  type: project
  originSessionId: c88e4493-4616-4711-877d-cb7a641409dd
---

Corwin's name for a backlog-clearing garden party: Claude prepares everything preparable, pops a box per decision (Corwin isn't fluent in frontmatter — Claude drafts, box confirms), Corwin signs on host, Claude verifies each signature actually landed before calling it freed.

First run 2026-07-08 (pre-shutdown; lab dark ~3 weeks from 07-10): Batch S all verified GOOD (the BAD verdicts were stale mount reads — see [[mount-stale-size-reads]] gpg corollary); stub litter #111 executed (4 stubs removed, concise → tests/fixtures/; folds ride pmo #112–#115); QA-3 stays gated; signing idiom adopted (machine-parsed files take detached/manifest sigs, never clearsign); Avalon lift.sh NO4C dead-block found (signed-but-contradicts-ruling), patched, re-signed; MANIFEST regen = pmo #116. Four advice records + commit drafts in claud-qa-hold/.

Ritual notes: don't edit freshly signed files for bookkeeping (advice/ carries the record); PLOT.md (SAVANNAH-side view, keeper-signed = adopted) made the batching workable. Possibly skill-shaped after a second run — [[session-rotate-skill]] is the adjacent close-out ritual.
