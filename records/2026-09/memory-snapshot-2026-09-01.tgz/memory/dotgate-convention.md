---
name: dotgate-convention
type: project
---
# .gate sign-post at directory roots
One dotfile: policy/reason/since + optional embargo/lift; nearest sign governs;
silence is not consent. Embargo gates egress (publish) orthogonally to policy —
no timer ever lifts it; a human edits the sign, the file history is the audit.
Shipped in polygram (gatefile.py + CLI, read|write|publish).
EthicsMinions may grow a tool-traffic guard against it; reseed regression with
SAVANNAH after PoC. Avoid requesting `.`-lead private folders as mounts —
`policy: none` is the in-band private marker. #dotgate #ethics
