---
name: c4-spoilers-capsule
description: "C4-SPOILERS capsule opened at Corwin's direction — findable local collection of C4 previews; kept off-cloud."
metadata: 
  node_type: memory
  type: project
  originSessionId: b04f62c9-bb55-4510-ade7-ece28827edfe
  modified: 2026-09-01T11:24:51.507Z
---

`F:\claude\AS4CE\AS4CE0001\C4-SPOILERS.md` — a findable capsule collecting C4 design previews that surface in sketches/cards before C4 is minted. Corwin directed it 2026-09-01 ("make a C4-SPOILERS memory capsule as you find information"). Append; never curate away.

**Kept LOCAL** (seat + memory), **not pushed to cloud/Drive** without his word — C4 is his unpublished project (a stop with a reason). Most current rows were already "dropped" (mentioned) this session, which he said is fine.

Seeds so far: iT=△=`<|` (the moment); ○=Tool Library; the trust arc; SEMAPHORE=S.tag; C4-does-git-transport-later; gate-states valid≠verified≠vouched≠rolled; the MEMORY(GRANT) formula (interpretation flagged).

**Why/How:** collect C4 previews as found; keep findable; don't let them leak outward. See [[vibrobeast-model]], [[trust-model-card]].
