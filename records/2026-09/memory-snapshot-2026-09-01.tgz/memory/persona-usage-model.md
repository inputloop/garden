---
name: persona-usage-model
description: "Usage-model sweeps 2026-08-03 — persona + fiction/fantasy/SF; models delivered, CANDIDATE decks placed in c4/decks (unmanifested on purpose), pub draft awaiting signature"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5bdd7ed0-d0a8-4f49-8d8f-86a4f7fd1d2b
  modified: 2026-08-03T06:51:42.546Z
---

Corwin commissioned two lexicon sweeps 2026-08-03 (transcripts + F:\claude one level
deep, Savannah excluded by instruction). Deliverables: MODEL-persona-usage.md and
MODEL-fiction-fantasy-usage.md (handed to keeper to place; INTERNAL class). C4-facing
distillations placed per his ask at /f/claude/c4/decks/persona-usage.deck.md and
fiction-fantasy-usage.deck.md — CANDIDATE, unsigned, deliberately NOT in
decks.manifest/decks.share so the C4 session notices them as unmanifested. Pub draft
/f/claude/pub/2026-08-03-the-borrowed-lamp-and-the-known-universe.md is unsigned and
unvouched (.gate untouched — it's signed; check-shelf will fail-closed until he signs).

Key persona resolutions: current default = person/seat/trait/gate tiers, "trait =
persona proper" (personas.tsv, PERSON.md); mass-noun persona = capability class with
unconditional fences; standing negative = lab persona (Dee 2026-07-05, not built);
"Persion" = person(a) slip; "personaly" = personally, never the noun; mint-marked typos
("laterl") never corrected; quoted-in-prompt ≠ authored-in-prompt.

Key fiction/fantasy resolutions: two registers — genre/identity ("Fantasy novelist",
"fan-fiction", "SF/F" — his only bare-SF; SciFi zero) vs fantasy-as-domain (gf-01,
his "absolutely vital" blessing 2026-07-27); borrowed-lamp rule (names/flavor cross,
deceit never; rename on crossing); Known-Universe OUT calls written down (races
taxonomy, ops-side "fog", persona↔house mappings); genre-IP stays in skzb/book lanes
(imposition test). Release-term linking deliberately kept away from C4 sessions until
near release — do not elaborate it there.

Gap both sweeps: 891-turn "term related tension resolution" session was running; fold
its outcome in later. Related: [[polygram-project]], [[c4-load-bearing-character]],
[[gates-engage-logic]].
