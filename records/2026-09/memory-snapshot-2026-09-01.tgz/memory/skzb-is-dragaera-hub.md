---
name: skzb-is-dragaera-hub
description: skzb is NOT an empty folder — it houses the pm Dragaera super-project; reconcile with the dragaera PMO key.
metadata: 
  node_type: memory
  type: project
  originSessionId: 1956aed7-1b31-48d3-a961-82307d2b4a80
---

`F:\claude\projects\skzb` is **not** an empty placeholder (PMO had it wrong;
todo #21 closed 2026-06-27). It contains `skzb/pm/` — the **Dragaera / Steven
Brust promotion super-project** ("pm" = Project Modeler): `instructions.md`,
`.model.md` (rotated), `dragaera_decision_matrix.xlsx`, `dragaera-rights-audit.md`,
and the new `MODEL-banter.md` + `MODEL-banter-hits.tsv`.

This is the on-disk home of the work the PMO **`dragaera`** key tracks, so the
two overlap. **Decided 2026-06-27 (PMO #72 DONE): keep them as separate keys —
`skzb` = the folder, `dragaera` = the hub — for now.** See [[pmo-supervisor]]
and [[polygram-project]].
