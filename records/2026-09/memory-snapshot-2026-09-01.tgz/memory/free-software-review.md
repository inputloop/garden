---
name: free-software-review
type: project
---
# Generalize medley-review to other Free Software projects? :SKILL:
medley-review captured Bob Proulx's calibration on the medley / savannah-medley
work. Some of it looks project-agnostic — the threat-model-first hardening gate,
"match the house idiom / don't modernize", "respect intentional style", and
"in-code TODOs are maintainer reminders, not a worklist". Open question: extract
those into a reusable skill for reviewing OTHER upstreams, or leave them folded
in medley-review? Deliberately parked until a 2nd review data point exists
(scheduled check 2026-07-12). One note on purpose so it stays HOLD — do not
synthesize yet. #free-software-review
