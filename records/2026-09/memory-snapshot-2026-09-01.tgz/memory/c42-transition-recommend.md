---
name: c42-transition-recommend
description: "C42 practice-transition RECOMMEND from Fabel5 landed at c4 root 2026-08-03 — R1 not-changing list first, R2 eclipse the change, R3 receipts round-trip, R4 prior + redo first pass, R5 attribution during mint"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5bdd7ed0-d0a8-4f49-8d8f-86a4f7fd1d2b
  modified: 2026-08-03T07:26:09.397Z
---

Keeper announced 2026-08-03 the fold/park/rotate practices are changing toward a "whole
new ballgame" (C42; the running term-tension session is likely part of the mint). My
assessment written down at keeper's ask as
/f/claude/c4/C42.Avalon-transitional.RECOMMEND.from.Fabel5.at.Avalon.md (filename his
mint, "Fabel5" spelling kept; CANDIDATE, unsigned, c4-root so the C4 session notices).
Core: concern conditional not categorical — protect the SEDIMENT (receipts, owners,
losers, append-only), not the idioms. Five recommendations R1–R5 each cite house
precedent; opening = make folds mechanical (source hash + version + receipt by
construction). When C42 practices settle, re-check my own conventions (fold language,
session-rotate, advice/ capture) against the new game before using them by habit.
Related: [[persona-usage-model]], [[gates-engage-logic]], [[plot-shelf-and-loop]].
