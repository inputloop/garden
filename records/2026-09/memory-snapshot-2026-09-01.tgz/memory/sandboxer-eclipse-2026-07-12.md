---
name: sandboxer-eclipse-2026-07-12
description: "Sandboxer eclipse verdict (seed 20260713) — PASS WITH AMENDMENTS; 2 true breaks (bash-cp cure, unqualified trust-HEAD); fold list F1-F7 awaits keeper."
metadata: 
  node_type: memory
  type: project
  originSessionId: a64cd6e2-0c24-40a5-901f-9957076befde
---

Eclipse pass on sandboxer, 2026-07-12, seed 20260713 (learn-local/bastian/techclass; learn-local empty → N=2 + bench). Verdict: **PASS WITH AMENDMENTS** — the two-reader core survived both biases everywhere; qualifiers broke. True breaks: (1) "copy to a fresh name" cure fails when bash is the copier — cp propagates the length-pin phantom (bench-reproducible in 3 steps: bash-create → file-tool lengthen → bash reads new bytes truncated at first-seen length); (2) unqualified "trust HEAD" — techclass firewallblockgen's nested upstream clone has a pristine HEAD that would revert Corwin's patches, and the mass-desync loop's `git diff` touches the index (use `git ls-tree -r HEAD`). Git scoping converged: object-reads OK, index-touch never, commits host-only — strengthens [[git-fails-on-windows-mount]].

**Fold list F1–F7** in `/f/claude/skills/.eclipse-increments/2026-07-12-sandboxer/verdict.md` (losers kept: doubt.md, reward.md); keeper applies + re-signs per QA-7. C7 (stale .pyc shadow) was the one clean PASS, field-confirmed live in techclass. mtime is never a tiebreaker on mounts. EM break still WAITS on the dual-signed drop per [[incoming-dual-signed-redteam]]. [[free-all-hopefuls-drill]] [[mount-stale-size-reads]]
