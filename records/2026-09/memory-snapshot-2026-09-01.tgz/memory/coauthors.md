---
name: coauthors
type: project
---
# Model This Book co-authors (federation)
Confirmed co-contributors: **Bryant Frankford** and **Kelsey** (was "one TBD").
Each gets a single-player behavior template (federation sibling of CORWIN.md),
their own to fill on their terms; skills ship through **ghostwheel**. Co-authors
need **no special sharing hold** — apply the methods to them. [[sharing-policy]]
