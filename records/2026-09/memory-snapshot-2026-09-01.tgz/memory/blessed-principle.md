# blessed-principle — the certified interlock (2026-07-01)

:PRINCIPLES: :CLAUD_QA_HOLD:

QA-6 staged (evidence archived 2026-07-08 → /f/SAVANNAH/archive/
blessed-principle-2026-07-01_2026-07-08_Archived-by-Claude.md): the six-clause
statement (mechanical consent; two attestations; universalism/egalitarianism →
four freedoms ordering; risk+opportunity; family/non-participant line;
instrument honesty). Minions pass clean (0 risk notices, drift SKIP).

Key finding: **QA-4 was Applied out-of-band** — Corwin mechanized the staged
consent-verification guard as the installed `consent-gate` skill. Ledger updated;
repo source folded into skills/consent-gate/ and minted (dist reminted 2026-07-01,
ethicsminions evolved source folded back too — installed cache had drifted ahead
of repo).

Tumblers (updated 2026-07-01 late): CLEARED — canon certified via
principle-reconcile MATCH cffeb6e9… (hub PRINCIPLES.md + svhck/CANON.md +
canon.sha256; F:\SAVANNAH authoritative copy unmounted, noted). CLEARED —
corwin.txt found (F:\claude, pointer interlocking prefs/minions/Mentat; arc
reduced-proposal == live prefs verbatim). Canon scope = decision-order →
attestations; QA-6 clauses 1/5/6 chamber-local, no drift. SETTLED: QA-5 held as deliberate grist for the next substantive ethicsminions change (Corwin, 2026-07-01) — don't re-litigate. Eclipse-pass rename approved ('entirely yum') and DONE: skills/eclipse-pass/ curated (kind language; legacy triggers noted; .eclipse-increments/ going forward, old dirs his to keep), eclipse-pass.skill minted 2026-07-01 — Corwin to install + uninstall torture-pass. Stray scripts/sedx44W4d needs his manual delete (mount blocks rm).
CLEARED 2026-07-02: PRINCIPLES v1.0 blessed by Corwin ("mint principles v1.0
please poly") and minted — minions re-run clean (0 risk) pre-landing; new
skills/principles/ carries the frozen six-clause statement (SAVANNAH-is-canon
caveat baked in; amend by minting v1.1, never in place). Artifacts:
principles.skill sha256=036791a20b4dce29…, principles-1.0.{tar.gz,zip} +
MANIFEST, advice 20260702-000746. Bundle verified byte-identical to source.
Not yet installed to the cache; not yet in the polygram-curation aggregate
(fold into next 0.5.x remint). Uncurated installs remaining: foaf,
savane-forensics (homes TBD).
