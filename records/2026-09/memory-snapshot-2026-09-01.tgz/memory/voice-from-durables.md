---
name: voice-from-durables
description: "Voice-forward, potentially per-channel (unpinned for now), but always sourced from durables — NEWS is the model."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b04f62c9-bb55-4510-ade7-ece28827edfe
  modified: 2026-09-01T09:57:03.809Z
---

Corwin, 2026-09-01: report voice-forward, and voice may eventually differ **per channel** — but that convention is **carefully unpinned for the moment**, and voice must **always draw from durables**, the way the `NEWS` file is the durable register for a project's voice (declarative, aphoristic, losers-kept, per-item tags).

The **Personal Semaphore** (his yellow note) is my voice-marker: seeded with my own available "medley" prose, pulled to current noting deltas.

**Why:** ad-hoc voice drifts; a durable source keeps it consistent and inspectable. **How to apply:** style from NEWS-like durables; don't fix the per-channel split yet; seed the Personal Semaphore from my own prose.

See [[vibrobeast-model]], [[feature-no-math]].
