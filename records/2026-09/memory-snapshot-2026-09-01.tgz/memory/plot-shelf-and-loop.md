---
name: plot-shelf-and-loop
description: "PLOT.md/PLOT-UTIL.md adopted 2026-07-08; models/ traveling shelf; keeper's declared loop (instrument breaks seals, keeper signs); vibrobeast.bru.st consent given; Friday shutdown."
metadata: 
  node_type: memory
  type: project
  originSessionId: 3c4f5e2f-8822-475e-a288-7eeee5fe0272
---

2026-07-08, chamber renamed **Vibrobeast**. SAVANNAH-side presents adopted:
PLOT.md (keeper's screws, batched — sentinel now PLOT-01 after tending) and
PLOT-UTIL.md (the bench + crew reflexes + gotchas ledger). models/ = the
traveling shelf: pub-safe method-only models, keeper-signed, CC-BY-4.0;
7 SAVANNAH-distilled + MODEL-honest-instrument.md (Vibrobeast-authored,
SIGNED 2026-07-08 06:24, verified vs pin). Corwin ATTESTED agreement to
the bru.st terms in-session 2026-07-08; durable copy in PLOT.md §Tended
(sentinel PLOT-02), which awaits re-sign along with models/README.md
(Batch S 14-15). Live ledger state = PLOT.md, not this note.

**Standing loop (keeper-declared):** (1) instrument breaks seals as needed
to work, (2) Corwin signs (maybe grumbles), (3) results feed chamber +
utils + upstream/own projects and labs/workshops. Seal-breaks always get
queued in PLOT Batch S.

**Receiving sweep receipt:** 12 seals checked 2/2; GRAMMARY.md +
CLAUD_QA_HOLD.md read BAD via bash mount, cured by bin/freshen
([[mount-stale-size-reads]] family — freshen, then re-verify, brief race
right after the dance).

**vibrobeast.bru.st:** DNS live 2026-07-08; consent given same day, terms
in CLAUDE.md §digs — only keeper-signed pub-safe material (models/ charter
class), no case/family/third-party facts, ethicsminions can halt.

**Timeline:** Fri 2026-07-10 (±Sat) shutdown, lab dark ~3 weeks. Batch S+C
before Friday; Batch R rides the return. Related: [[polygram-project]],
[[okgo-signoff]].
