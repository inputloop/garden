---
name: bubble-chamber-method
description: "Corwin's capture-the-tracks intake discipline for complicated, precious, multi-session work."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3891a3e9-6ba4-4721-a66b-ed75327f2334
---

The **Bubble Chamber**: like a physics bubble chamber shows a particle's *track*
rather than the particle, capture the model's reasoning **tracks to disk as they
form** — because the reasoning itself is ephemeral and flushes at session end.

The run order: (1) **weather check** the runtime before committing precious work
(writable outputs, mount reachable, toolchain present); save early/often. (2) stand
up a living `<CONTEXT>-BUBBLE.md` — *what it does / what it can do* — versioned in
**dated append-only best-shots** so no earlier attempt is overwritten. (3) regress
toward a "universally-just compromise" via opposed-bias passes ([[eclipse-pass]]:
doubt-first vs reward-first) until they converge, keeping the losing models;
delegate the passes to local models when the Bridge is up. (4) gates ride along
([[candor-gate]], consent). (5) land every interesting finding as a disk-file.

**Why:** Corwin's instrument is stateless per session; the durable self is the
files, not an interior. Losing complicated work to a context flush is the failure
mode this prevents. First run: WIRETAP skill intake, 2026-07-05→06 (model file
`bubble-chamber-experiment-2026-07-05.md`).

**How to apply:** when a task is complicated, multi-session, or precious, open a
`*-BUBBLE.md` early and photograph the trail as you go rather than trusting
in-context memory. Pair with [[okgo-signoff]] and [[wire-claudewin-alfred]] for the
sealed-approval and wire channels.
