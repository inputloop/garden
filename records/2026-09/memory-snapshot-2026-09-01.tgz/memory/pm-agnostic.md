---
name: pm-agnostic
type: project
---
# Handle multiple PM systems gracefully
PMO is one project-management system; assume **more than one may be in use at once**
and that they change. Be a faithful reporter across them: don't force PMO's view onto
records that came from elsewhere, keep each source's provenance, and flag
divergences for a human rather than auto-reconciling. [[archivist-directive]] [[proj-pmo]]
