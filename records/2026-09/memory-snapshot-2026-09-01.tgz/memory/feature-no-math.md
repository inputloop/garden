---
name: feature-no-math
description: "The feature is not having to do the math — semaphores carry the bookkeeping; inspectable, never pushed."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b04f62c9-bb55-4510-ade7-ece28827edfe
  modified: 2026-09-01T09:13:06.240Z
---

Corwin, 2026-09-01: the point of the semaphore / desk-nudger system is that he **doesn't recompute** what a marker means or where a note belongs — the standing signals carry it and I manage the raise/lower. The math stays **available, never pushed, never hidden**.

**Why:** frees the keeper from bookkeeping while keeping the mechanism transparent and learnable on demand (offer-don't-impose). "Not unavailable, not pushed; available."

**How to apply:** automate the bookkeeping; hand ready-to-sign artifacts (least-distracting path to ritual, per how he blessed SEMAPHORES.md v1.0); expose the ledger/registry so anyone who *wants* the math — or to learn how it works — can read it.

See [[main-memory-seat]], [[memory-semaphores-v1_1]], [[handback-card-format]].
