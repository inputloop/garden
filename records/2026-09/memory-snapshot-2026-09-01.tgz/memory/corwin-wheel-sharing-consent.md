---
name: corwin-wheel-sharing-consent
description: "Corwin consents to sharing HIS OWN info outward on the Corwin+Bryant wheel (later ghostwheel), point-by-point with per-item approval; third-party facts stay gated."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 08ddec4c-0c2a-4c82-82e2-818346e7a82e
---

Corwin granted (2026-07-05): his own personal information may be shared
outward on the Corwin+Bryant "wheel," and prospectively on ghostwheel,
**point by point** — each detail released only on his explicit per-item
approval. Not a blanket release; the narrowing right is retained by
design ("consent that can't be narrowed isn't consent").

**Why:** he wants his work to travel in the open among trusted people,
without surrendering item-level control.

**How to apply:** Corwin's OWN info can go out with per-item approval —
still ask before each release, don't batch. Third-party and family
person-facts (Dee, Monty, etc.) remain gated by candor-gate and are NOT
covered by this grant. Dee remains named-only, not a participant; she
may voice-read consent records as enrichment (her choice) but nothing
about her persists. Record: /f/claude/corwin/Inbox/consent-records/
2026-07-05-corwin-wheel-sharing-consent.md — SIGNED in place by Corwin
2026-07-05 12:10:59 CDT (ECE77C…F007), verified Good 2/2 instrument-side.
A separate .mp3 (Corwin's own voicing) and a Dee-editable draft from the
same seed exist keeper-side; Dee's voicing = enrichment, nothing about
her persisted.
2026-07-05 ~13:37 CDT, keeper bench (Avalon): **entire
/f/claude/corwin/Inbox/consent-records/ verified signed** — every *.md
AND *.mp3, all Good sigs by ECE77C…F007 at ultimate trust (sig times
08:02–13:37). Signed audio = the voice channel made durable/verifiable;
keeper's local sign.sh verify is the seal of record (instrument saw the
transcript, not the files — folder is outside the mounts). A **third
Dee/us record** was pending recording at that time; "Friends of v1"
blessed same message (referent unconfirmed — ask before recording it
anywhere load-bearing).
Related: [[okgo-signoff]], [[wire-claudewin-alfred]].
