---
name: skilltank-torture
type: project
---
# Torture discipline baked into skilltank :SKILL:
The "torturing corwin" discipline is industrialized inside **skilltank**: a runnable
torture harness (DRIVES vs DESCRIBES/DRIFTS, regression-aware) + a final **consent
gate** (identity is a variable; no publisher nailed on without consent — *nobody
ships unconsented*). When skilltank runs **unsupervised**, judgment delegates to the
local **CORWIN** model (`{USER^^}`). Holds until/unless factored to its own Persona.
[[coauthors]] [[sharing-policy]]

GO-HARDER: >=3 passes (ideas/models/personas) whenever models are in play; ethics minions released before the persona pass (disinclination noted, OK); expensive persona pass quietly skippable for a checked-out operator; incremental work-product parked with a subtle keep-offer, never silently discarded.
