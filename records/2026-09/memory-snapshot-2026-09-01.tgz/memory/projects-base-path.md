---
name: projects-base-path
description: "F:\\claude\\projects is the go-forward base path for all of Corwin's projects."
metadata: 
  node_type: memory
  type: project
  originSessionId: 6035d4a1-4d56-4cd9-9b18-94280bf0a6a9
---

`F:\claude\projects` is the go-forward base path for everything Corwin and I
work on. He intends to relocate each existing project there over time and will
handle most of the moves himself.

As of 2026-06-27 it holds: polygram (see [[polygram-project]]), org-c4,
card-game, svhck, techclass, paclam, AIVB, the dragaera super-project hub
(loose `dragaera-super-project-CLEAN.md`), the new [[pmo-supervisor]], and two
empty placeholders (ccspt, skzb) whose purpose is still unknown. The PMO ledger
tracks their status.
