---
name: savannah-forensics
description: Savannah/Savane forensics engagement — green-lit and in progress as of 2026-06-27.
metadata: 
  node_type: memory
  type: project
  originSessionId: 3aec2ca0-f922-4743-b470-15f23aa904db
---

GNU Savannah / Savane forensic security + breach-notification work. As of 2026-06-27 Corwin is **green-lit and move-in has begun — status: in progress**. Tooling is the `savane-forensics` skill (svhck-forensics suite). Feeds polygram via the frozen `savane-upstream` extern (frozen @ 9f1c2ab) — see [[polygram-project]].

One reviewer is still expected to comment; treat their feedback as pending/incoming alongside Corwin's own move-in notes. [[publish-code-bru-st]]

**2026-07-12 milestone — first draft went to Bob.** Two clearsigned journal essays published to the open shelf F:\claude\pub (CC BY 4.0, keeper-signed, narrow-share terms declared in pub/README): "The Door and the Lock" (discovery account) and "The Instrument's Account" (second op, machine-authored). Method-level public facts: HCK-033 was dismissed as false-positive at the door while the lock (an authz check never written, since 2016) stayed broken; the two suspended users were exonerated (one benign 2-second use, one key never used); the coverage→positive-control→targets read-order caught a false "host clean" before it shipped. Same day: safe-method drop corwin/Inbox/2026-07-12-from-savannah (SEAMS 0.2, MEMPRESS 0.1, run-card skill + template v0.2 — template carries a flagged keeper-veto decision on two case-flavored lines). Case detail stays enclave-side; journals are the pub-safe record.

**Guard calibration (Corwin, 2026-07-05):** full stop stands on Savannah *detail* in-tree (hosts, cases, forensics) — but Savannah's *existence*, and that Corwin does important work helping it, is not a secret and needn't be treated as one. Savannah things were withdrawn from F:\claude root to the SAVANNAH enclave (F:\SAVANNAH\imported-2026-07-05-from-workspace, sha-checked, keeper-affirmed): SAVANNAH.md, svhck, bob/ (medley). Inbox pair (CorwinLanding_SAVANNAH, savannah-pushout) stays in root, frozen, content-clean per SAVANNAH-side review. Manual skill toggles are keeper consent records — CONSENT-RECORD-skill-toggle-2026-07-05.md at root, **COUNTERSIGNED**: clearsigned in place by Corwin 2026-07-05 10:59:17 CDT (ECE77C…F007), independently verified Good instrument-side same hour; keeper affirmed the direction four times total. Signing flow: dialogs only for general stops; otherwise Corwin sees drops himself.
