---
name: proj-modelthisbook
type: project
---
# modelthisbook — QUARANTINED (book about modeling)
"Model This Book": a book about modeling — the MODEL/DEBUG method, the dimensional
model, memory→skill synthesis (polygram), Mentat/minions. Carry-forward lens
**dim6 = uniting/integration**; `CORWIN.md` is the flagship persona instance, kept
as a versioned line. **QUARANTINE:** personal/orthogonal notes about Corwin do
**not** flow into this project's `memory/` — it is deliberately walled to prove the
method's efficacy on its own terms. Read-only from the chamber. [[proj-polygram-self]]
