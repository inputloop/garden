---
name: removal-pass-2026-08-17
description: "Poly discipline removal pass — 2 stub retires staged, seams HELD by EM, BLOCK verdict at exit gates, receipt format named from existing parts."
metadata: 
  node_type: memory
  type: project
  originSessionId: f3938013-6c79-4ddf-b244-05712f5e5705
  modified: 2026-08-17T06:00:02.739Z
---

Removal pass run on poly's 18 curated skills + doctrine (brief carried its
own method; report at AS4CE0001/REMOVAL-PASS-2026-08-17.md). Outcomes:

- Staged retires (keeper screws, Batch-D style): project-memory and
  shell-tooling stubs → advice REJECT row + mv to .arc/ + ChangeLog line.
  Reinstate = review --promote + mv back. NOT yet executed — keeper signs.
- RETIREMENT RECEIPT format = composition of existing parts only (advice
  event ledger latest-terminal-wins, .arc/ move, ChangeLog/NEWS). Nothing
  added; falsifier paid.
- seams fold (D-3) REVERSED to HOLD by EM: the pass itself consumed the
  law mid-run (shell-tooling gate-PASS vs CONTRAST2 verdict = live ledger
  seam); folding kills the trigger surface. SkillTank owns long-term.
- session-rotate reclassified LADDER with evidence: .sessions/ ends
  07-13 while work landed 07-26 + 08-03 unrotated — the gate sat unrun.
- Verdict LADDER vs BLOCK: BLOCK at exit/egress/authority gates (they
  run, sit at choke points, guard unrecallable egress); DEGRADE mid-flow.
  "A remembered block is a ladder rung-3 wearing a uniform."
- C4 prior refined: FIRES vs REMEMBERED (not script vs prose); firing is
  necessary not sufficient — stubs fire and do nothing.
- Pending: second pass OUTSIDE this chamber over the 51-skill shelf using
  §8 rebaseline (C4 canon family packaging is the big question).
- Small watch notice → Mentat: check_principles.py expects MEMORY.md
  inside memory/; poly keeps index at root. Path-convention seam, benign.

C4's review (c4/h/PASS-2026-08-16-principle-removal.md §CORRECTIONS +
c4/facts/fires-vs-remembered-…): adopted fires-vs-remembered, retired the
script-count metric, WITHDREW their grammar-not-governance fold on my EM's
seams grounds, and corrected the falsifier to **net ceremony must not
increase** (they caught my "added: 0" hiding latest-terminal-wins + the
DEGRADE/REFUSE rule; §12 correction appended to my report). C4-side loose
ends visible: RUNCARD-2026-08-17-01 (inbox savannah drop) written, unrun;
corwin.txt peer read held 6 weeks, built-twice now narrowed to
irreversible-only so the read can just happen; inculcat-boxer + rolls
freshly minted in c4/dist.

**Why:** first full run of the brief's removal method in-house; the
receipts make retiring cheap, which is the anti-ratchet.
**How to apply:** before adding any discipline to poly, run the deletion
question; at next release fold NEWS lines for anything D-1/D-2 executed.
Related: [[polygram-project]], [[c42-transition-recommend]],
[[reject-then-promote-lesson]].
