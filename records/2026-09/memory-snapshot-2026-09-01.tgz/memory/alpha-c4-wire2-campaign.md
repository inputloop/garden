---
name: alpha-c4-wire2-campaign
description: "The signed 8-stage microscope campaign on Bryant's ALPHA v0.1.2 (2026-07-08) — outcomes, the EP design, and where everything landed."
metadata: 
  node_type: memory
  type: project
  originSessionId: c88e4493-4616-4711-877d-cb7a641409dd
---

Corwin's first keeper-signed campaign prompt (prompt/Drafts/Alpha-C4-Wire2.md, lineage pre/post/confirmed all signed) ran 2026-07-08, all 8 stages. Key outcomes: ALPHA v0.1.2 eclipse-passed PASS with offered patch set P1–P5 (axis-4 reframe: verification floor = artifact class, relationship = intent-trust; §7 split STRONG/ADJACENT; UA-masquerade caveat); A2A v1.0 Signed Agent Cards verified dual-source — industry independently arrived at pinned-identity. New design center: **Execution Proposal (EP)** — content pin (sha256 + public repo + commit) + committer pin + scope (registers/run-level/dominance U-D-C-H) + proposer sig + user counter-sign as the grant, register as PROOF; "nothing in C4 may require an AI agent" named as the anti-lock-in baseline. EP emerged independently from wire side and build side (convergence). Deliverables in AS4CE0001/models/c4/ (all keeper-signed), lifted to Avalon stage (lift.sh MENTIONED→NOTE semantics live-verified) and corwin/pub. Follow-ups: pmo #117 (ccspt bake when third consumer appears), #118 (Alfred wire thread post-trip — Corwin reviews before anything rides the wire). Losers + full trail: .eclipse-increments/2026-07-08-ALPHA-0.1.2/. Related: [[free-all-hopefuls-drill]], [[c4-load-bearing-character]].
