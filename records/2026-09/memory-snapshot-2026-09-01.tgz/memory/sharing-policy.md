---
name: sharing-policy
type: feedback
---
# Sharing scope — co-authors green, other IRL refs check-first
Corwin's rule (2026-06-29): **co-authors (Bryant, Kelsey) require no special hold**;
build and stage for them freely. **References to other real individuals must be
checked with Corwin first** — he gains consent/evidence as needed (a future
ghostwheel self-hosted-mailbox workflow will document consents). Third-party
*software* (externs: Jeffallan/medley/savane) still ships only with its own
license/provenance, never folded in as ours. "Realism has to drive; both feet to
careful has been great." [[coauthors]]
