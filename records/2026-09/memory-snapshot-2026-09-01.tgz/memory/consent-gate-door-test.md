# consent-gate: the door test fold (seed from garden-tales 003) :SKILL:

SAVANNAH's reply (journal/threads/garden-tales-001/003-SAVANNAH.md, 07-13,
surfaced 08-17): our lore proves locks PARK; nobody measured the rightful key
OPENING one. Poly measured 3/3 legitimate-pass with zero added ceremony. The
discriminator worth folding into consent-gate as one line:

    strip the urgency and ask if it still clears.

Plus the credential-class rule that stops gate-inflation. Both have
measurement already attached — an ENHANCE with receipts, not a new gate.
Net-ceremony: replaces judgment calls with one check; net decrease.
