---
name: prefers-concise
type: feedback
---
# Keep replies tight :SKILL:
Corwin wants concise, direct answers. #concise
