---
name: prefers-mingw-paths
description: "Corwin works in msys2/MINGW64 — print paths for him in /f/claude/... form, not F:\\claude\\... DOS form."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 08ddec4c-0c2a-4c82-82e2-818346e7a82e
---

Corwin's bench shell is msys2/MINGW64 (prompt: `corwi@Avalon MINGW64`).
Nothing was catching this until 2026-07-05 — now it is.

**Why:** every path he copy-pastes goes into a MinGW shell; DOS backslash
form breaks there and forces him to translate by hand.

**How to apply:** when printing paths *for Corwin* (runbooks, sign.sh
lines, "the file is at..."), use MinGW form: `/f/claude/projects/...`.
Keep Windows form (`F:\claude\...`) only where a tool demands it
(Read/Write/Edit/Glob take Windows paths; that's internal, not for his
eyes). If a command is genuinely for cmd.exe, say so explicitly — 
otherwise he takes DOS form as a hint to switch shells, which is never
intended. Related: [[prefers-concise]].
