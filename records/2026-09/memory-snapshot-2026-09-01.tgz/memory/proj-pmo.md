---
name: proj-pmo
type: project
---
# pmo — the cross-project supervisor
Corwin's in-house PMO: dependency-free supervisor over projects under
`F:\claude\projects`, two TSV ledgers (`projects.tsv`, `todos.tsv`) + POSIX `bin/`.
Drive via the `pmo` skill, never hand-edit its generated README/index. This chamber
(`polygram`) is one row on that ledger. [[proj-polygram-self]]
