---
name: cand-project-memory
type: project
---
# Keep every cowork project memory-aware :SKILL:
Recurring need: each cowork project should have a hub memory file here, kept in
sync as projects come and go — scaffold a stub for any project missing one, and
reconcile the `MEMORY.md` index against the notes on disk. Runnable, repeatable,
stdlib/POSIX (C4 idiom: tiny override-able functions, tests-first). A real tool,
not just a fact. #project-memory
