---
name: dprojects-portfolio
description: "D:\\projects is Corwin's big general projects folder (139 dirs); portfolio analysis lives in F:\\claude\\projects\\program-analysis.org."
metadata: 
  node_type: memory
  type: project
  originSessionId: 6035d4a1-4d56-4cd9-9b18-94280bf0a6a9
---

`D:\projects` is Corwin's sprawling general projects folder — 139 directories
plus a large loose-file pile, a mix of his own work and many upstream clones.
A full portfolio review is at `F:\claude\projects\program-analysis.org`
(0–10 societal/social/industry scoring, weighted 50/40/10, rough $ costs).

Key facts that persist beyond this analysis:
- Authorship is cleanly read from git origins: Corwin's = github **mplscorwin**,
  sr.ht **~mplscorwin**, Forgejo **code.bru.st/corwin**. Everything else is an
  upstream clone (exclude from his portfolio).
- The highest-value work (under societal+social weighting) is volunteer FOSS:
  GNU **savannah** security (matches [[savane-forensics]] + the F: svhck work),
  **ansible-configs** (live FSF infra), **EmacsConf** organizing, **dungeon-mode**
  (his flagship Emacs game engine, multi-author, EmacsConf 2020), and
  **org-c4-themes** (the substrate for the [[pmo-supervisor]]).
- Flagships exist as 3–6 duplicate/snapshot copies — consolidate before work.
- A scattered 5-repo "collaborative audio editor" effort (sargasso, mp3p0,
  vaudioplex, audiofall) should collapse into the **inputloop** brand.
- Dragaera House "Cycle" emblem art (in `dragaera/` and `amx-workspace/assets/cycle`)
  is a promo asset for the Dragaera super-project.

SECURITY (must fix before publishing): committed secrets — `FSD/.google_api_key`,
a Discord token in `comicchat-discord/.env`, an SSH key in `sdf/.../.ssh/id_rsa`;
malware — a `ubh` backdoor plugin in `greatbigbard.com` (EOL WordPress).
SENSITIVE (never publish): `tax`, `bob`, `IRC`, `esme_music`.
