---
name: publish-code-bru-st
description: "Corwin's self-hosted Forgejo is code.bru.st — primary publish target for projects."
metadata: 
  node_type: memory
  type: reference
  originSessionId: 6035d4a1-4d56-4cd9-9b18-94280bf0a6a9
---

`code.bru.st` is Corwin's own self-hosted Forgejo instance and the primary place
he wants most projects published (some may also publish elsewhere).

Caveat: as of 2026-06-27 the per-project repo URLs recorded in
[[pmo-supervisor]]'s `projects.tsv` (e.g. `https://code.bru.st/corwin/<key>`)
are *assumed*, not confirmed — verify before relying on them. Repo sync is
deliberately NOT supervised from the PMO project yet.

Confirmed working 2026-07-02: `ssh://forgejo@code.bru.st/corwin/as4ce`
(remote name `upstream`, branch `master`) — Corwin pushed polygram v0.5.3
+ tag from his machine. Other per-project URLs still unverified.
