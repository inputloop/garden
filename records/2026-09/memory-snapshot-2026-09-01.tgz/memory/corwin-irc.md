---
name: corwin-irc
type: user
---
# Big on IRC; libera.chat regular
Corwin is "very big on IRC" and mostly frequents **libera.chat**. He **moderates**
for the **GNU Emacs** project and **FSF/GNU** channels, plus some miscellaneous
channels. Public details he mentions freely at conferences — fair to note. [[corwin-public-fsf]]
