---
name: avalon-assembly-line
description: "Keeper's 2026-07-13 ruling — Avalon is an assembly line; thorny tools become mini-projects on a bench before graduating to utils/; lift+drop approved as a pair."
metadata: 
  node_type: memory
  type: project
  originSessionId: a64cd6e2-0c24-40a5-901f-9957076befde
---

Corwin's ruling 2026-07-13 (signed at `/f/claude/projects/Avalon/stage/incoming/2026-07-13/ASSEMBLY-LINE.md`):

- **lift + drop are a pair.** Lift guards what comes IN (provenance); drop guards what goes OUT (selection). The hard gate stands — drop refuses anything not already promoted. Corwin's own workaround for his own blocks is to park a folder and ask for help bringing it in, NOT to widen the gate. *A block you route around by asking is a good block; one you route around silently is broken.*
- **Avalon is an assembly line.** Thorny tools (movepack, drop) become **mini-projects** in `work/<tool>/` — tool + README + `t/` tests + Makefile — and graduate to `utils/`/`tools/` on stated criteria: tests green on a disposable target, README a stranger can run from, path-lint -s clean, signed, keeper has read it. Plain make; autotools only when the pain is real.
- **awk/sed rule:** compose the standard tools, never reinvent them; reach for Python (stdlib) when the shell starts lying (nested quoting, structure, arithmetic, silent wrongness). Exception: C4 may internalize an operation when a signed assembler cannot depend on a tool it can't pin — deliberate, argued, written down.

Also ruled this session: **a push is a fact; a release is a claim** — Corwin pushed without cutting 0.7.0 and was right to; pre-cut certification card at `claud-qa-hold/RUNCARD-2026-07-13-03-pre-cut-certification.md`. [[sandboxer-eclipse-2026-07-12]] [[polygram-project]]
