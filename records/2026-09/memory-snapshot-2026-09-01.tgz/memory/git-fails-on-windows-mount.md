---
name: git-fails-on-windows-mount
description: git init/commit fails on the AS4CE0001 Windows mount from the sandbox.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ef0e765b-aaa0-4746-93c2-25c8f0f19ff5
---

`git init` on the mounted Windows folder (F:\claude\...) from the sandbox fails: git writes `.git/config`/index but the bytes don't land readably ("bad config line 1", "unknown error reading configuration files"). Same write-desync that truncated source files mid-write.

**Why:** the Windows mount doesn't honor git's file-locking/rewrite semantics from the Linux sandbox.

**How to apply:** don't run git directly on the mount. Either commit from the user's own machine, or provide an init script for them to run locally. Also: the **Edit/Write file tools themselves silently desync on this mount** (report success, leave the file truncated mid-line — confirmed repeatedly 2026-06-27 on cli.py, externs.py, test files, even a 1-line __init__.py version bump). Don't trust an Edit/Write here. Reliable path: build the FULL file in /tmp (sandbox), `ast.parse` it, `cp` to the mount, then verify on disk — line count, `ast.parse`, AND a fresh `python3 -B -c import` (stale .pyc / stale mount reads can mask it). Per [[polygram-project]], [[polygram-test-kit-gaps]] and the sandboxer skill.
