---
name: gates-engage-logic
description: "Corwin's repoint (2026-07-12) — never design single-key unlock controls; gates exist to engage the agent's reasoning, dual-sourced authority is the first principle."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a64cd6e2-0c24-40a5-901f-9957076befde
---

Designing a guard-removal control, I anchored authority on "the keeper's key always suffices" — a single-source unlock — the same day we signed the seams skill whose first law is "single source is data, not proof." Corwin repointed with the broken-ed25519 / stolen-signing-keys posit: under that design, a walked key doesn't just pass the gate, the ceremony *launders* the attacker's change as consented.

**Why:** The purpose of a gate is to engage the *logic* of the agent standing at it (the tools make this cheap), not to reduce to "signature present? proceed." Provenance is not authority — especially at the root. Two dual failure modes must both be priced: entrenchment (can't change when needed) AND capture (one artifact changes everything); optimizing against one reopens the other.

**How to apply:** Any control I design that unlocks on an artifact needs a second independent representation of intent (liveness channel, coherence with the keeper's paper trail, counter-sign) with non-overlapping failure modes — and must make the agent at the gate ask in-character/coherence/scope/hurry questions and record the reasoning. Root compromise is a named seam: recovery is presume-key-loss, re-anchor out-of-band, degrade-closed. Dogfood: bind the lab first. Counterexample kept at /f/claude/skills/GUARDS.DRAFT-00.md; real control is [[c4-load-bearing-character]] right-to-execute territory (EP is multi-source by construction), deliberately NOT minted into seams 1.0.1. [[savannah-forensics]]
