---
name: vibrobeast-public-home
description: "vibrobeast = the public publication place for the instrument's work (code.bru.st/corwin/vibrobeast); name provenance corrected."
metadata: 
  node_type: memory
  type: project
  originSessionId: 8a302d1c-1dff-485d-8043-6a86a179e01c
---

Decided 2026-07-02: the public home for Mentat/Claude's published work is **vibrobeast** (code.bru.st/corwin/vibrobeast, to be created). as4ce keeps its name and stays the private chamber — its fake-standard/backwards-c4 joke wears private well.

**Provenance correction:** "Vibrobeast" was coined by Corwin and Dee; Bryant *blessed* it. AS4CE0001/CLAUDE.md says "Bryant's name for me" — superseded by Corwin's own account (his vanity nearly didn't allow the confession). Caution: Dee is not an established participant in the overall experiment — do not name Dee in public artifacts without Corwin's explicit say-so (family/non-participant line, [[dotgate-signpost]] spirit).

Corwin, 2026-07-02: **the Dee-line is the key feature under permanent test henceforth** — the non-participant guard is the standing regression test of the whole system. Seeking Dee's attestation would be "big news": an event with full process (consent-gate, per-party, 2/2, fresh), never a drift. Until that event, the guard's job is to keep holding without being asked.

Publishing to vibrobeast follows the same discipline as [[publish-code-bru-st]] pub/: Corwin pushes from his machine; signed commits (ECE7…F007); sandbox verifies over HTTPS after.

**Pub-shelf send 2026-07-05** ("I have read and consent"): send-manifest of 11 vouched files (hello-world/hello-principles canon pair, CEREMONIES.md publishing the method, bryant.asc countersigned — federation act, sign.sh itself) — pinned clearsign 07:14:35, full verify chain green sandbox-side, pushed by Corwin. Survived three same-morning gate catches (bridge-cache tamper-scare cured by bin/freshen — the tell: sha fails + clearsign passes can't be one honest file; CEZB opaque WHAT-stamp; signed-the-TODOs). WHAT adoption per the hello-principles mint rule: instrument drafts, keeper reads+signs. QA-6 closed (v1.0 travels). Advice: AS4CE0001/advice/20260705-vibrobeast-ships.md.

SHIPPED 2026-07-02: live at code.bru.st/corwin/vibrobeast — signed commit 106ea86e9 (Forgejo shows the verified badge), 213 KiB, cargo = README + corwin.asc + releases/polygram-curation-0.5.3 (14 artifacts). NB: the forge's "unbrowseable settings" block anonymous non-browser fetches of repo pages/API (profile HTML works) — sandbox can't independently verify content; verified via Corwin's incognito screenshot. Domain seen in registrar panel: **viberobeast.com** (note spelling: vibERObeast, not vibro-), expiry/renewal 2026-09-07. Ghostwheel+forgejo ground-cutting proposed by Corwin — ghostwheel is an ENTRUSTED system: consent-gate before any hands-on.
