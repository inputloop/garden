---
name: memory-semaphores-v1_1
description: "Candidate SEMAPHORES v1.1 for the seat work — SEAT, MANIFEST-MEMORY, STRANDED (pending Corwin's blessing)."
metadata: 
  node_type: memory
  type: reference
  originSessionId: b04f62c9-bb55-4510-ade7-ece28827edfe
  modified: 2026-09-01T13:08:05.208Z
---

Note-of-notes about the signal vocabulary I now manage. Registry `F:\claude\SEMAPHORES.md` was blessed at v1.0 (2026-07-07). **BLESSED emphatically by Corwin 2026-09-01** — now SEMAPHORES **v1.1** in both copies (root + models/), sentinel-guarded so no re-sign was needed. These are conventions now, not candidates. Plus `GROW` (the accretion protocol) and the model-pairing rule:

- **`SEAT` / `SEAT@<store>`** — declares the authoritative home for a note/note-class. Bare = Vibrobeast (`AS4CE0001/memory`); `SEAT@SAVANNAH` = a carve-out. Lowered by Corwin/C4 (canon-level).
- **`MANIFEST-MEMORY`** — the findable ledger of every "is/was a memory-shaped note," keyed by **content sha256 (identity)**, path as **hint**; per-row disposition `bring-in` / `REF@home` / `HOLD` (reused from `MANIFEST-IDEATION`). Lowered by the reseat landing a note with a hash-match receipt.
- **`STRANDED`** — reachable only in a fenced/retired root, not yet in the seat; awaiting reseat. Lowered by a verified copy landing in the seat (→ `TRACED`).

Raise cheap, lower by ceremony (that asymmetry is the point). Prepared as a paste-and-sign block in the DRAFT §5 — no math owed.

See [[main-memory-seat]], [[manifest-hash-not-path]], [[feature-no-math]].
