---
name: corwin-public-fsf
type: user
---
# Public free-software standing
Public, conference-mentioned facts: **Savannah Hacker** / FSF-GNU volunteer; signs
the **Windows binaries for GNU Emacs releases**; **EmacsConf** core organizer
(2020/2023 talks); author of `dungeon-mode` and `emacs-w64`. Career: Senior
Solutions Architect, ~20-yr IT consultant. (Data-broker PII deliberately excluded —
see modelthisbook/CORWIN-SECRET.) [[corwin-hosting-teaching]] [[corwin-irc]]
