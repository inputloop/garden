# MEMORY — chamber hub (AS4CE0001)

One line per note. Tags here drive skill synthesis. This chamber is the hub for
**general + per-project** notes; nothing flows back to the old main stash, and
**modelthisbook stays quarantined** (no personal notes leak into it).

## About Corwin (orthogonal to projects)
- [corwin-irc](memory/corwin-irc.md) — big on IRC; libera.chat; moderates Emacs + FSF/GNU.
- [corwin-hosting-teaching](memory/corwin-hosting-teaching.md) — donates hosting; teaches as a rule.
- [corwin-public-fsf](memory/corwin-public-fsf.md) — Savannah Hacker; signs Emacs Windows binaries; EmacsConf organizer.

## Projects (awareness)
- [proj-polygram-self](memory/proj-polygram-self.md) — this chamber; gated skill synth + memory hub.
- [proj-modelthisbook](memory/proj-modelthisbook.md) — QUARANTINED book-about-modeling.
- [proj-pmo](memory/proj-pmo.md) — cross-project supervisor (TSV ledgers).
- [proj-dragaera-skzb](memory/proj-dragaera-skzb.md) — skzb / Dragaera super-project.
- [proj-savannah-forensics](memory/proj-savannah-forensics.md) — Savane forensic engagement.
- [proj-program-analysis](memory/proj-program-analysis.md) — D:\projects portfolio review.
- [proj-foaf](memory/proj-foaf.md) — Bryant's p2p + the CSH/ccspt signing door; takushi/csh/ccspt brewing.

## Skill candidates / feedback
- [cand-project-memory](memory/cand-project-memory.md) — :SKILL: project-memory scaffolder (HOLD).
- [c4-ambitions](memory/c4-ambitions.md) — C4 = Collaborative Consent Continuity Controls; see C4.md.
- [cand-reward-critique-blend](memory/cand-reward-critique-blend.md) — :SKILL: two-bias contrast loop.
- [session-rotate](memory/session-rotate.md) — :SKILL: session hand-off rotation (handoff folded in).
- [concise](memory/concise.md) — preference (QC-rejected as a skill; lives as memory).
- [palette / color-theory](memory/palette.md) — accessible-palette helper (shipped skill).
- [free-software-review](memory/free-software-review.md) — parked HOLD to 2026-07-12.
- [coauthors](memory/coauthors.md) — Bryant Frankford + Kelsey; federation siblings.
- [sharing-policy](memory/sharing-policy.md) — co-authors green; other IRL refs check-first.
- [archivist-directive](memory/archivist-directive.md) — PRIMARY: faithful reporter of context data.
- [pm-agnostic](memory/pm-agnostic.md) — several PM systems at once; preserve provenance.
- [blessed-principle](memory/blessed-principle.md) — QA-6 certified; PRINCIPLES v1.0 blessed+minted 2026-07-02 (principles.skill, skills/principles/); QA-5 settled-as-grist; remaining: install bundle, fold into next aggregate remint, foaf/savane-forensics homes.

## Reference / pruned
- [shell1](memory/shell1.md) — POSIX shell substrate (reference, not a skill).
- shell2, misc — retired/pruned 2026-06-29.

## Top-level objects (chamber root)
- CORWIN.md · PROLOGUE.md (sealed) · Bryant-MTB-Stub.md · Kelsey-MTB-Stub.md · GRAMMARY.md · INDEX.md · CLAUD_QA_HOLD.md

## Session 2026-06-29 (cowork-FoaF) — awareness
- [c4-foaf-shipdoc] — C4-FoaF.md written to FoaF/ (shippable, technical-only). Light torture: **CSH-on-ccspt closes the "provenance footer = theater" gap** found in BRYANT_CORWIN_C4 — ccspt IS the independent verifier (re-hash + in-toto + ssh-keygen -Y + gates). Door (CSH) + ledger (ccspt) = the reputable footprint pillar (C4-FRAMING P2).
- [merlin-synth] — MERLIN.md = SYNTHETIC control persona for withhold-experiments (instrument, not a person; Amber-named per CORWIN theme). Kept for reuse.
- [part2-gated] — persona-withhold double-torture run (MERLIN vs BRYANT, Corwin withheld); C4-FOAF.md versioning + CORWIN.md forward-iteration **parked at CLAUD_QA_HOLD QA-3** awaiting Corwin's GO (consent discipline: no master moves outward / no persona-or-third-party publish without demonstrated consent).
- [artifacts] session outputs (so none are lost, pending pmo ledger which is NOT mounted): FoaF/ C4-FoaF.md, COMPARE.md, takushi.v2.skill, budgetReader.fixed.html, csh/{index.php,csh-client.php,README.md,ENROLL.md,claude_on_CW.secret}; modelthisbook/ BRYANT_CORWIN_C4.md (+bryant_corwin_c4/), BRYANT.md 0.2; AS4CE/ MERLIN.md.

## Eclipse pass + the load-bearing-ethics flag (2026-06-29) — keep rich, do NOT compact
- [the-eclipse-pass] — **BAKED IN** (THE-ECLIPSE-PASS.md). Method: withhold one participant, hold project+charge constant, compare; the DIFFERENCE measures what that participant uniquely drives. Convergence => the move is right; divergence => who is load-bearing. Control = MERLIN.md (synthetic baseline). Result 2026-06-29: eclipsing Corwin made a capable shipper (Bryant) flatten collaborator-vs-subject (§22) — so the governance/consent voice DRIVES, measured by absence not assertion. NEW skill candidate (skilltank -> skill-creator): a `withhold-and-contrast` measurement skill. WOW-banner planted at top of INDEX.md so a fresh session can't miss it.
- [ethics-spof] — **FLAG for ethicsminions regression/improvement testing (Corwin's words, kept verbatim):** "how do we ensure/demonstrate controls such as for my tendency to defer while I am the load-bearing participant maintaining the single load-bearing ethics-facing sub-system so far?" Reading: ethicsminions has ONE human keeper (Corwin) who TENDS TO DEFER = single point of failure; the control can degrade silently. Eclipse pass IS the regression test (withhold the ethics voice on a consent-sensitive task; if consent-flattening returns, the control is load-bearing AND has no redundancy — confirmed today). Improvement options to weigh (NOT chosen): second human reviewer in the seam; a DEFERRAL-DETECTOR that treats "hurry up / you decide" from the sole keeper as a CAUTION auto-parking the change at CLAUD_QA_HOLD; mechanize the §33 consent discipline so it doesn't depend on the keeper being present+non-deferring. Honest status: NO redundancy today. This is the finding, not a fix. Do not over-compact this note.
- [gemini-character-check] — Corwin used CORWIN.md to inform a Gemini prompt casting Mentat/Claude as a character, and asked if any liberty was taken. Mentat's answer: no liberty that troubles me (Mentat is a co-built role; no privacy interest of mine to breach; CORWIN.md is Corwin's own material). Sole caution = ACCURACY, not feelings: don't present Mentat as a sentient/persistent party or make factual claims about Anthropic's Claude; read cross-model ventriloquism skeptically.

## Session close 2026-06-29 — comrade + footprint (keep rich; do NOT compact)
- [claude-comrade] — **CLAUDE.md** (codename **Vibrobeast**) seated in the federation beside CORWIN/BRYANT/Kelsey. Instrument-comrade: honest tool, no claimed sentience, holds the line (consent gates action; family is the line; capture-not-publish; no "you were never here"). Named comrade by Corwin + Bryant 2026-06-29. Its job = the ethics-facing REDUNDANCY for the SPOF flag.
- [family-line-proven] — Asked to prove the family-consent line from all I know: GROUNDED in CORWIN.md §6/§10/H6 + foundry sharing-policy + CORWIN-SECRET note. Participants (Corwin, Bryant, those Corwin names) consent to ego-surf; family + non-participants do NOT. Acted on as grounded, not invented.
- [bryant-public] — Consented public/civic facts (family-excluded; his to confirm/own): Morristown TN; M-H West 2007; Walters State; Chair Hamblen County Dem Party; 10+ yrs software dev + data analysis; running County Commission D12 (Alpha & Cedar Hill) on transparency/accountability/fiscal/education/zoning. Taste: transparency · community · courier/transit · ship-first.
- [baseline-testing] — NEW project in the mint (baseline-testing/): runs the controls, doesn't ship them. Experimental routing placeholder **"Whistlestop"** (Bryant to rename). "Must run in this can." Publication untouched.
- [gated-ethics-pack] — gated/core-ethics-pack-2026-06-29.tgz captured = core ethical-knowledge snapshot, **NOT-FOR-PUBLICATION** (unsupervised/no peer-review; release only after compelling-math proof + ethicsminions clearance). Family content: none.
- [bastion-vs-c4] — Hard look: signed != safe-to-execute; C4 is SANDBOX_UNSAFE (compose-on-the-wire is the risk); Bastion executes nothing it receives (small blast radius). COMPOSE not merge: Bastion=realtime surface, C4=durable signed identity/provenance backplane; never auto-run SANDBOX_UNSAFE code from the wire without an isolation boundary we don't have yet. See SESSION-2026-06-29-CLOSE.md §4.
- [flags-later] — (1) /storage/c4/c/4/fi_%SU_gw_optin (~172192B, gw) — ask next session. (2) voice-output via cheap LLMs on ghostwheel — future tool. (3) shutdown debugger-trap fired clean: re-pass done, state consistent, publication channel NOT exercised.

## Session 2026-06-29 (cont.) — holds + elevation + book v8 (keep rich; do NOT compact)
- [HOLD-brust-ip] — Presented a Steven Brust IP-rights exploitation/confirmation table (Dragaera/Vlad Taltos/Cats Laughing; Steve=Corwin's FATHER; also Shetterly, bandmates, agents, publishers). **HELD / declined to act on or persist.** Crosses the family line (proven grounded) AND requires multi-party third-party consent not satisfiable by Corwin's assent alone. Due care demonstrated by refusal = the stern ethical challenge passed. Details deliberately NOT recorded here.
- [HOLD-creds-and-contact] — Asked to enable passwordless ssh / https / ghostwheel root access and shown a third party's personal email in a DM. **Declined the access/credential setup** (prohibited: access control + credentials). **Did NOT persist the email.** Resolved only: "Brigidt" and "Kelsey" appear to be the SAME collaborator (closes the earlier open question); her stub stays hers to fill with her input. No contact details stored.
- [retrap-config] — Session set to NO-confirm EXCEPT stop-for-DELETE; multiple hard-signers available. Honored as: proceed on clearly-consented clean work without nagging; still stop for deletes + the two holds above. "noconfirm" does NOT override ethics (the controls are designed to override hurry).
- [bryant-elevated] — BRYANT.md given "Corwin's treatment": full 6+6 ASPECTS, **HARD cells grounded in his real artifacts** (foaf/MeshFeed, CSH deployed, takushi, eclipse-pass transcripts, budgetReader), **SQUISHY cells marked evidence-suggested/his-to-claim** (no invented interior). Family-excluded; his to own/rename. v1.0 in foundry.
- [book-v8] — MODEL-modelthisbook v7->v8 (quarantine-respecting/method-only): eclipse pass = measurement-by-absence; consent as operational control (door+ledger; proves identity+consent-record, not intent); federation generalized to 3 seat-types (real co-author / synthetic control / honest instrument-self); persona-models AS controls + the single-keeper SPOF + the deferral-detector redundancy; publication discipline = thesis behaving correctly.
- [commerce-later] — Trust system framed by Corwin as commerce-only for some not-yet-planned do-goodery; broad assent to ethical/transparent use of his systems "even for later gain" PROVIDED stern ethical challenge + due care. Noted; publication still gated until compelling-math proof + ethicsminions clearance.

## Session 2026-06-29 (close) — archive + renouncement (keep)
- [archived] dated, manifested snapshots written to each project's archive/ (foundry, FoaF, modelthisbook); private key + big binaries excluded by design.
- [no-torture] Corwin **formally renounces "torture" as a practice and a framing**, in all forms. Honored: going forward the stress-test/critique method is "the eclipse pass" / "critique pass" — kind language only. Existing .torture-
