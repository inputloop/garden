---
name: gamma
description: Gamma, a new fixture skill. Use on 'gamma go'.
---

# Gamma

*v0.1 (2026-01-02)*

## Deliver
A file.
