---
name: alpha
description: "Alpha: a fixture skill, now with a gate. Use when someone says 'alpha this', 'run alpha' or 'gate alpha'. Hands back one note and a receipt."
---

# Alpha

*v1.1 (2026-01-02) · author: Fixture.*

## Trigger
Say 'alpha this'.

## Protocol
1. Read. 2. Gate. 3. Write the note.

## Gates
No note without a receipt.

## Hand back
The note, first, then the receipt.

## Version notes
**v1.1 (2026-01-02):** a gate, on the keeper's word ("gate it"). 1 change: (1) the Gates section.
**v1.0 (2026-01-01):** first.
