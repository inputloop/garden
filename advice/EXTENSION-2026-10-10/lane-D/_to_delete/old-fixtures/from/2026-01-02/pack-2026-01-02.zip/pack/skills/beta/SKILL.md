---
name: beta
description: Beta, a fixture skill that never changes. Use for 'beta check'.
metadata:
  version: "2.0"
---

# Beta

## Boot order
One step.
