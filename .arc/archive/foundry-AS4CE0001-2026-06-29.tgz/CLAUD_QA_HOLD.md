# CLAUD_QA_HOLD — the approval desk

A standing category for **changes Claude prepares but will not land without
Corwin's explicit go**. The human-in-the-loop seam: when a chat needs attention to
finish, the item is parked here and a **box pops** (Apply / Hold / Reject).
Watchword: *faster to application*. Every decision is dated to `advice/`.

## How it works
- **Label** `:CLAUD_QA_HOLD:` parks a note/artifact (distinct from the gate's
  skill-`HOLD`: this holds *prepared changes* of any kind).
- **Staging dir** `claud-qa-hold/` keeps the prepared file beside the live one for
  a clean diff before it lands.
- **The box** offers Apply / Hold / Reject; applying copies into place + logs advice.

## Open items
| id | item | status |
|----|------|--------|
| QA-2 | c4-consent-quartet | **ADOPTED AS START** (identity/package/subscription/register); ongoing — ≥6 dim6 refinement rounds; folded into model.md + GRAMMARY/INDEX. |
| QA-3 | Part-2 persona-withhold double-torture (MERLIN vs BRYANT, Corwin withheld) + C4-FOAF.md versioning + CORWIN.md forward-iteration | **PREPARED, GATED** — torture run + notes kept; **awaiting Corwin's explicit GO** before any CORWIN.md master moves outward or any persona/third-party content publishes (family/third-party content review required first). |

| QA-4 | ethicsminions CONSENT-VERIFICATION guard (the ALL/ANY gate; dual public-source verify; deferral-detector; mechanical so it survives the keeper being absent) | **PREPARED, GATED** — staged at claud-qa-hold/ethicsminions-consent-verification-guard.md; awaiting Corwin's Apply. Parks Brust-IP + creds by construction; run-loop continues on clean work. |

| QA-5 | AI_GUARD_PROVENANCE_CLAUDE — demonstration of which ethical guards are Claude's OWN (fired against Corwin's instruction) vs shared vs Corwin-initiated | **PREPARED, GATED** — staged at claud-qa-hold/AI_GUARD_PROVENANCE_CLAUDE.md; the SPOF redundancy disproof; awaiting Apply into ethicsminions. |

## Resolved
| id | item | resolution | date |
|----|------|-----------|------|
| QA-1 | ethicsminions SKILL.md rework | **APPLIED** — clean body copied over the skilltank-contaminated live one. | 2026-06-29 |

## feeds →
`advice/` (apply/reject trail) · `model.md` · `GRAMMARY.md` · `skills/`
