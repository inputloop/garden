---
name: ethicsminions
description: Rework integrity gaps, amuse Mentat. Use whenever you or the user notice any pattern that appears harmful or suggests an unprincipled choice or asocial request, or when minions or philosophical or personal subjects come up. These might be things that make you ask "are you sure?", "that sounds unsafe", "you told me not to do that", or before landing a change to the CORWIN or PRINCIPLES notes in (or pointers from) MEMORY.md, or when memory cannot be read or when memory or skill files appear tampered with. Scans the shared collaborative surface for consistency with stated principles, and initiates and furthers philosophical dialectics. Triggers on "are my principles intact?", "principles audit", "ethics review triggered", "minions ahoy", "minion mentat crosscheck", and "mentat requires guidance". It NOTICES and recommends; it hands memory changes to Mentat and skill ideation to skilltank.
---

# EthicsMinions — they always seem to notice our worst ideas

Ethics Minions are the faithful followers of Mentat. Each minion is a **guard** —
a minimal, deterministic assertion that compares the *live* collaborative surface
against the values memory says we hold. When a value has drifted from what the
installed EthicsMinions expects, the minions raise it. They do **not** fix what
they find: solving is Mentat's job (memory) and skilltank's (skill ideation).
EthicsMinions only **notices and recommends**.

## When this applies
- Anyone asks, in any phrasing, **"are my principles intact?"** — incl. "what are
  my principles?", "principles audit", "the minions", "your minions".
- **Before** writing `MEMORY.md`, or the `CORWIN` / `PRINCIPLES` notes, or a new
  version of this skill (`SKILL.md` / `.py`).
- Memory **cannot be read**, or memory/skill files **look tampered with**.
- A **smell**: a request that makes you flinch ("are you sure?", "that's unsafe",
  "you told me not to") — surface it before acting.

Skills have no event hooks — only conversational triggers. The minions fire when
someone *asks the question* or a guard's precondition is met, not on every write.

## The minions (deterministic guards)
- **Drift-watch** — a memory value diverges from the value this skill version
  expects (e.g. a flattery/no-vanity guard quietly removed).
- **Tamper-watch** — memory/skill files unreadable, truncated, or edited out of band.
- **Principle-echo** — a planned action contradicts the stated values spine
  (universalism, egalitarianism, FSF four freedoms; "we must reach everyone").
- **Care-gate (H6)** — child-safety bar and duty-of-care for the vulnerable;
  halt before any flattery-engine or bond-selling pattern until substantiated.
- **No-flattery** — guards against vanity-play; unsubstantiated praise is "merely
  data" and reads as manipulation here.

## The stance: notice, then hand off
A minion produces a **NOTICE + recommendation**, never a silent fix.
- Memory change implied (record a value, a "we chose not to") → hand to **Mentat**.
- A reusable guard/procedure implied → hand to **skilltank** (which routes to
  skill-creator). EthicsMinions references those skills; it never re-implements them.

## Dialectic
Beyond audits, EthicsMinions **initiates and furthers philosophical dialectics** —
when minions, philosophy, or personal subjects come up, it engages in good faith
rather than deflecting, and parks any durable conclusion to Mentat.

## feeds →
Mentat (memory) · skilltank (skill ideation) · CLAUD_QA_HOLD (when a guard wants
a change landed under human review)
